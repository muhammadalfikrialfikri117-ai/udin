export interface MenuItem {
  id: string;
  name: string;
  category: 'food' | 'snack' | 'drink';
  price: string;
  priceNum: number;
  description: string;
  rating: number;
  reviewsCount: number;
  image: string;
  tags: string[];
  isPopular?: boolean;
  isNew?: boolean;
}

export interface LinkItem {
  id: string;
  title: string;
  subtitle: string;
  iconName: string;
  url: string;
  badge?: string;
  isFeatured?: boolean;
  color?: string;
  category: 'order' | 'social' | 'location' | 'community' | 'merch';
}

export interface LocationItem {
  id: string;
  name: string;
  city: string;
  address: string;
  mapUrl: string;
  hours: string;
  phone: string;
  facilities: string[];
  image: string;
  isHQ?: boolean;
}

export interface EventItem {
  id: string;
  title: string;
  date: string;
  time: string;
  location: string;
  description: string;
  category: 'music' | 'community' | 'workshop' | 'esports';
  image: string;
}

export interface ReviewItem {
  id: string;
  author: string;
  role: string;
  content: string;
  rating: number;
  date: string;
  avatar: string;
}

export const BRAND_INFO = {
  name: "Starblack Coffee Group",
  handle: "@starblackcoffee.id",
  tagline: "#beliveintheprocess • Coffee, Pastry, Cake, Eatery & Co-Working",
  shortDesc: "Pioneer of modern specialty coffee, artisan pastries, and vibrant creative hubs since 2010. Serving premium Arabica, legendary traditional Kopi Saring, and a cozy space to connect & create.",
  hours: "Open Everyday // 08.00 - 23.00 WITA",
  whatsappPhone: "+628981125445", // From actual data
  instagramUrl: "https://www.instagram.com/starblackcoffee.id/",
  tiktokUrl: "https://www.tiktok.com/@starblackcoffeegroup",
  mainWebsite: "https://linktr.ee/starblackcoffeegroup",
  logo: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?q=80&w=400&auto=format&fit=crop"
};

export const QUICK_LINKS: LinkItem[] = [
  {
    id: "link-wa-order",
    title: "Order Fast via WhatsApp",
    subtitle: "Direct delivery & takeaway reservation with our friendly baristas",
    iconName: "MessageCircle",
    url: "https://wa.me/628981125445?text=Halo%20Starblack%20Coffee,%20saya%20ingin%20memesan%20kopi/reservasi%20tempat.",
    badge: "Fast Response",
    isFeatured: true,
    color: "from-amber-500 to-orange-600",
    category: "order"
  },
  {
    id: "link-gofood",
    title: "Order on GoFood / GrabFood",
    subtitle: "Get your daily caffeine boost delivered straight to your doorstep",
    iconName: "ShoppingBag",
    url: "#menu-section",
    badge: "Promo Available",
    isFeatured: true,
    color: "from-emerald-500 to-teal-600",
    category: "order"
  },
  {
    id: "link-maps-kandangan",
    title: "Starblack Kandangan Kota Hub",
    subtitle: "Jl. Merah Johansyah, Kandangan Kota - Dine-in & Co-working",
    iconName: "MapPin",
    url: "https://maps.google.com/?q=Starblack+Coffee+Kandangan+Kota",
    badge: "Open Now",
    category: "location"
  },
  {
    id: "link-maps-bireuen",
    title: "Starblack Bireuen HQ",
    subtitle: "Pusat Kota Bireuen - The legendary homebase since 2010",
    iconName: "MapPin",
    url: "https://maps.google.com/?q=Starblack+Coffee+Bireuen",
    category: "location"
  },
  {
    id: "link-ig",
    title: "Follow Instagram (@starblackcoffee.id)",
    subtitle: "Stay updated with daily vibes, secret menu drops, and events",
    iconName: "Instagram",
    url: "https://www.instagram.com/starblackcoffee.id/",
    badge: "2.5K+ Followers",
    category: "social"
  },
  {
    id: "link-community",
    title: "Join Community Broadcast Channel",
    subtitle: "The Not-So-Secret Menu, promo codes, & local creator meetups",
    iconName: "Radio",
    url: "https://www.instagram.com/starblackcoffee.id/",
    badge: "VIP Perks",
    category: "community"
  },
  {
    id: "link-merch",
    title: "Official Starblack Merchandise & Beans",
    subtitle: "Freshly roasted single origin beans & exclusive streetwear tees",
    iconName: "Package",
    url: "#merch-section",
    category: "merch"
  },
  {
    id: "link-booking",
    title: "Book Co-Working & Meeting Room",
    subtitle: "High-speed Wi-Fi, ergonomic seats, power outlets & projector",
    iconName: "Users",
    url: "#coworking-section",
    category: "community"
  }
];

export const MENU_ITEMS: MenuItem[] = [
  {
    id: "m1",
    name: "Starblack Signature Palm Sugar Latte",
    category: "drink",
    price: "Rp 28.000",
    priceNum: 28000,
    description: "Our signature double espresso shot perfectly blended with creamy fresh milk and authentic organic aren palm sugar. Perfectly balanced sweetness with rich caramel notes.",
    rating: 4.9,
    reviewsCount: 428,
    image: "https://images.unsplash.com/photo-1541167760496-1628856ab772?q=80&w=800&auto=format&fit=crop",
    tags: ["Best Seller", "Signature", "Iced/Hot"],
    isPopular: true
  },
  {
    id: "m2",
    name: "Legendary Kopi Saring Aceh",
    category: "drink",
    price: "Rp 18.000",
    priceNum: 18000,
    description: "The classic robust pulled coffee filtered through traditional cloth bag. Deep, heavy body with a legendary aroma that energizes your entire day.",
    rating: 4.9,
    reviewsCount: 512,
    image: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?q=80&w=800&auto=format&fit=crop",
    tags: ["Traditional", "Authentic", "Strong"],
    isPopular: true
  },
  {
    id: "m3",
    name: "Caramel Macchiato Velvet",
    category: "drink",
    price: "Rp 32.000",
    priceNum: 32000,
    description: "Velvety steamed milk with vanilla syrup, marked with premium espresso and finished with a luxurious caramel crosshatch drizzle.",
    rating: 4.8,
    reviewsCount: 230,
    image: "https://images.unsplash.com/photo-1485808191679-5f86510681a2?q=80&w=800&auto=format&fit=crop",
    tags: ["Creamy", "Sweet Treat"],
    isNew: false
  },
  {
    id: "m4",
    name: "Arabica Single Origin V60 Pour Over",
    category: "drink",
    price: "Rp 35.000",
    priceNum: 35000,
    description: "Hand-brewed Gayo / Kintamani premium beans with bright acidity, notes of stone fruit, brown sugar, and clean floral aftertaste.",
    rating: 4.9,
    reviewsCount: 186,
    image: "https://images.unsplash.com/photo-1517256064527-09c73fc73e38?q=80&w=800&auto=format&fit=crop",
    tags: ["Specialty", "Manual Brew", "Low Acid"]
  },
  {
    id: "m5",
    name: "Sanger Espresso Premium",
    category: "drink",
    price: "Rp 22.000",
    priceNum: 22000,
    description: "A beautiful harmony of robust espresso and condensed milk shaken with ice. The ultimate local favorite for casual hangout.",
    rating: 4.8,
    reviewsCount: 340,
    image: "https://images.unsplash.com/photo-1570968915860-54d5c301fa9f?q=80&w=800&auto=format&fit=crop",
    tags: ["Local Pride", "Sweet & Strong"],
    isPopular: true
  },
  {
    id: "m6",
    name: "Almond Butter Croissant",
    category: "snack",
    price: "Rp 26.000",
    priceNum: 26000,
    description: "Flaky French-style butter pastry filled with rich almond frangipane cream and topped with toasted almond flakes and powdered sugar.",
    rating: 4.9,
    reviewsCount: 289,
    image: "https://images.unsplash.com/photo-1555507036-ab1f4038808a?q=80&w=800&auto=format&fit=crop",
    tags: ["Fresh Baked", "Best Pairing"],
    isPopular: true
  },
  {
    id: "m7",
    name: "New York Lotus Biscoff Cheesecake",
    category: "snack",
    price: "Rp 38.000",
    priceNum: 38000,
    description: "Dense, creamy baked cheesecake layered on a crunchy spiced Biscoff biscuit crust, topped with caramelized cookie butter spread.",
    rating: 4.9,
    reviewsCount: 194,
    image: "https://images.unsplash.com/photo-1533134242443-d4fd215305ad?q=80&w=800&auto=format&fit=crop",
    tags: ["Premium Dessert", "Indulgent"],
    isNew: true
  },
  {
    id: "m8",
    name: "Starblack Crispy Chicken Sambal Matah",
    category: "food",
    price: "Rp 42.000",
    priceNum: 42000,
    description: "Juicy fried chicken cutlet served over warm fragrant rice, topped with authentic Balinese raw shallot & lemongrass spicy chili oil.",
    rating: 4.8,
    reviewsCount: 310,
    image: "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?q=80&w=800&auto=format&fit=crop",
    tags: ["Chef's Rec", "Hearty Meal"],
    isPopular: true
  },
  {
    id: "m9",
    name: "Spaghetti Aglio Olio Smoked Beef",
    category: "food",
    price: "Rp 39.000",
    priceNum: 39000,
    description: "Al dente pasta tossed in premium extra virgin olive oil, garlic slices, chili flakes, and generous slices of savory smoked beef brisket.",
    rating: 4.7,
    reviewsCount: 165,
    image: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?q=80&w=800&auto=format&fit=crop",
    tags: ["Eatery", "Italian Twist"]
  },
  {
    id: "m10",
    name: "Kyoto Uji Matcha Latte",
    category: "drink",
    price: "Rp 30.000",
    priceNum: 30000,
    description: "Authentic ceremonial grade green tea matcha whisked to perfection with silky steamed milk. Earthy, rich, and naturally antioxidant-packed.",
    rating: 4.8,
    reviewsCount: 220,
    image: "https://images.unsplash.com/photo-1536256263959-770b48d82b0a?q=80&w=800&auto=format&fit=crop",
    tags: ["Caffeine Alternative", "Refreshing"],
    isPopular: false
  },
  {
    id: "m11",
    name: "Sunset Tropical Peach Refresher",
    category: "drink",
    price: "Rp 26.000",
    priceNum: 26000,
    description: "Sparkling soda infused with real peach slices, mint sprigs, and passionfruit pureé. The perfect thirst quencher for hot tropical days.",
    rating: 4.9,
    reviewsCount: 178,
    image: "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?q=80&w=800&auto=format&fit=crop",
    tags: ["Mocktail", "Fizzy"],
    isNew: true
  }
];

export const LOCATIONS: LocationItem[] = [
  {
    id: "loc-kandangan",
    name: "Starblack Kandangan Kota Hub",
    city: "Kandangan, South Kalimantan",
    address: "Jl. Merah Johansyah, Kandangan Kota, Kabupaten Hulu Sungai Selatan",
    mapUrl: "https://maps.google.com/?q=Starblack+Coffee+Kandangan+Kota",
    hours: "Mon - Sat: 08:00 - 23:00 | Sun: 09:00 - 23:00 WITA",
    phone: "+62 898-1125-445",
    facilities: ["High-Speed Wi-Fi", "Indoor AC Space", "Outdoor Smoking Area", "Co-Working Desks", "Power Outlets", "Mushola (Prayer Room)", "Free Parking"],
    image: "https://images.unsplash.com/photo-1554118811-1e0d58224f24?q=80&w=800&auto=format&fit=crop",
    isHQ: true
  },
  {
    id: "loc-bireuen",
    name: "Starblack Bireuen Origin",
    city: "Bireuen, Aceh",
    address: "Pusat Kota Bireuen (Near Main Square), Kabupaten Bireuen",
    mapUrl: "https://maps.google.com/?q=Starblack+Coffee+Bireuen",
    hours: "Everyday: 08:00 - 24:00 WIB",
    phone: "+62 811-688-990",
    facilities: ["Traditional Saring Bar", "Community Space", "Outdoor Rooftop", "Live Acoustic Stage", "Gaming Lounge Area"],
    image: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?q=80&w=800&auto=format&fit=crop",
    isHQ: false
  }
];

export const COMMUNITY_EVENTS: EventItem[] = [
  {
    id: "ev1",
    title: "Weekend Acoustic & Jamming Night",
    date: "Every Saturday Night",
    time: "20:00 - 23:00 WITA",
    location: "Starblack Kandangan & Bireuen Hub",
    description: "Chill with local acoustic talents while sipping our signature Palm Sugar Latte. Open mic available for all visitors!",
    category: "music",
    image: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: "ev2",
    title: "Tech Creators & Steemian Meetup",
    date: "March 15, 2026",
    time: "16:00 - 18:30 WITA",
    location: "Co-Working Room, Kandangan Hub",
    description: "Monthly networking event for digital creators, developers, crypto enthusiasts, and writers. Free drip coffee for registered attendees.",
    category: "community",
    image: "https://images.unsplash.com/photo-1531482615713-2afd69097998?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: "ev3",
    title: "Latte Art & Manual Brew Workshop",
    date: "March 28, 2026",
    time: "10:00 - 13:00 WITA",
    location: "Main Bar Starblack",
    description: "Learn the secrets of milk steaming, latte art pouring, and V60 extraction with our Head Barista. Certificate & goodie bag included.",
    category: "workshop",
    image: "https://images.unsplash.com/photo-1511920170033-f8396924c348?q=80&w=800&auto=format&fit=crop"
  }
];

export const REVIEWS: ReviewItem[] = [
  {
    id: "rev1",
    author: "Sayed Anzi",
    role: "Local Guide & Food Blogger",
    content: "Starblack Coffee is my absolute favorite place to hang out and write. The atmosphere is incredible, the Wi-Fi is super fast, and the Sanger Espresso is the best in town!",
    rating: 5,
    date: "2 weeks ago",
    avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=200&auto=format&fit=crop"
  },
  {
    id: "rev2",
    author: "Razack Pulo",
    role: "Digital Nomad",
    content: "Legendary coffee shop! I've been coming here since their early days. The owner and staff are incredibly energetic and friendly. Great food menu too - try the Chicken Sambal Matah!",
    rating: 5,
    date: "1 month ago",
    avatar: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?q=80&w=200&auto=format&fit=crop"
  },
  {
    id: "rev3",
    author: "Putri Amanda",
    role: "University Student",
    content: "The co-working space is so comfortable for finishing assignments. The Biscoff Cheesecake is to die for. 10/10 recommendation for anyone looking for a cozy aesthetic cafe.",
    rating: 5,
    date: "3 weeks ago",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=200&auto=format&fit=crop"
  }
];

export const MERCH_ITEMS = [
  {
    id: "merch1",
    name: "Starblack Gayo Premium Beans (250g)",
    price: "Rp 85.000",
    desc: "100% Arabica washed process. Medium-dark roast with notes of dark chocolate, brown spice, and sweet caramel.",
    image: "https://images.unsplash.com/photo-1587735243615-c03e25aae0b4?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: "merch2",
    name: "#beliveintheprocess Heavy Cotton Tee",
    price: "Rp 165.000",
    desc: "Premium oversized fit 100% combed cotton black t-shirt with embroidered brand slogan. Perfect streetwear for coffee lovers.",
    image: "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: "merch3",
    name: "Starblack Stainless Tumbler Hot & Cold",
    price: "Rp 145.000",
    desc: "Double wall vacuum insulated 500ml tumbler. Keeps your Palm Sugar Latte iced for 12 hours or hot for 8 hours. Get 10% discount on refills!",
    image: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?q=80&w=800&auto=format&fit=crop"
  }
];
