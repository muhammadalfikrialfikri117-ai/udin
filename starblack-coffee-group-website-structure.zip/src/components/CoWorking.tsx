import React, { useState } from 'react';
import { Users, Calendar, Wifi, Zap, Monitor, Coffee, MessageSquare } from 'lucide-react';
import { EventItem } from '../data/coffeeData';
import { useApp } from '../context/AppContext';

export const CoWorking: React.FC = () => {
  const { data } = useApp();
  const events = data.events;
  const brand = data.brandInfo;
  const whatsappNumber = (brand.whatsappPhone || '+628981125445').replace(/\D/g, '');

  const [bookingType, setBookingType] = useState<'desk' | 'room' | 'event'>('desk');
  const [attendees, setAttendees] = useState<string>('2-4');
  const [date, setDate] = useState<string>('');
  const [time, setTime] = useState<string>('14:00');

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const message = `Halo ${brand.name}, saya mau melakukan reservasi %0A%0A*Tipe Reservasi*: ${bookingType.toUpperCase()}%0A*Jumlah Orang*: ${attendees}%0A*Tanggal*: ${date || 'Segera'}%0A*Jam*: ${time}%0A%0AMohon konfirmasi ketersediaan tempat. Terima kasih!`;
    window.open(`https://wa.me/${whatsappNumber}?text=${message}`, '_blank');
  };

  const perks = [
    { title: "Ultra-Fast Wi-Fi", desc: "Dedicated fiber optic connection up to 100 Mbps stable download & upload.", icon: <Wifi className="w-5 h-5 text-emerald-400" /> },
    { title: "Power Outlet at Every Seat", desc: "Never run out of battery. Multi-plug sockets equipped at all desks.", icon: <Zap className="w-5 h-5 text-amber-400" /> },
    { title: "Meeting Projector & TV", desc: "Available for rent in private meeting rooms for presentations & pitch decks.", icon: <Monitor className="w-5 h-5 text-blue-400" /> },
    { title: "Unlimited Drip Refills", desc: "Special co-working day passes get 30% discount on single origin manual brews.", icon: <Coffee className="w-5 h-5 text-orange-400" /> },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-16 animate-in fade-in duration-300">
      
      {/* Intro section */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 font-semibold text-xs uppercase tracking-wider">
          <Users className="w-3.5 h-3.5" />
          <span>Connect • Build • Create</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-['Outfit']">
          Co-Working Hub & Community
        </h2>
        <p className="text-zinc-400 text-sm sm:text-base leading-relaxed">
          Whether you're a digital nomad, student, developer, or startup founder, Starblack provides the perfect ecosystem to get your best work done.
        </p>
      </div>

      {/* Perks Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {perks.map((perk, idx) => (
          <div key={idx} className="p-6 rounded-3xl bg-zinc-900 border border-zinc-800 shadow-xl space-y-3">
            <div className="p-3 bg-zinc-800/80 rounded-2xl w-12 h-12 flex items-center justify-center">
              {perk.icon}
            </div>
            <h3 className="text-lg font-bold text-white font-['Outfit']">{perk.title}</h3>
            <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">{perk.desc}</p>
          </div>
        ))}
      </div>

      {/* Booking Form Box & Events Box Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        
        {/* Left Form (5 cols) */}
        <div className="lg:col-span-5 bg-zinc-900 border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="space-y-1">
            <h3 className="text-2xl font-bold text-white font-['Outfit']">Reserve Your Table</h3>
            <p className="text-xs text-zinc-400">Guaranteed seats for your team or solo work session</p>
          </div>

          <form onSubmit={handleBookingSubmit} className="space-y-5">
            <div>
              <label className="block text-xs font-bold text-zinc-400 uppercase mb-2">Select Space Type</label>
              <div className="grid grid-cols-3 gap-2 text-center">
                {(['desk', 'room', 'event'] as const).map((type) => (
                  <button
                    type="button"
                    key={type}
                    onClick={() => setBookingType(type)}
                    className={`py-2.5 px-3 rounded-xl font-bold text-xs uppercase tracking-wider transition-all cursor-pointer ${
                      bookingType === type
                        ? 'bg-amber-500 text-zinc-950 shadow-md shadow-amber-500/20'
                        : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
                    }`}
                  >
                    {type === 'desk' ? 'Desk Pass' : type === 'room' ? 'Meeting Rm' : 'Community'}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-400 uppercase mb-2">Number of Attendees</label>
              <select
                value={attendees}
                onChange={(e) => setAttendees(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-amber-500"
              >
                <option value="1 (Solo)">1 Person (Solo Desk)</option>
                <option value="2-4">2 - 4 People</option>
                <option value="5-8">5 - 8 People (Meeting Room)</option>
                <option value="10+">10+ People (Community Gathering)</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-zinc-400 uppercase mb-2">Date</label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-amber-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-zinc-400 uppercase mb-2">Time</label>
                <input
                  type="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:opacity-95 text-white font-bold text-sm shadow-xl flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <MessageSquare className="w-5 h-5" />
                <span>Confirm RSVP via WhatsApp</span>
              </button>
              <p className="text-[10px] text-zinc-500 text-center mt-2">No advance deposit required for standard desk reservations.</p>
            </div>
          </form>
        </div>

        {/* Right Events List (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-2xl font-bold text-white font-['Outfit']">Upcoming Community Events</h3>
              <p className="text-xs text-zinc-400">Live music, workshops, and networking</p>
            </div>
            <span className="text-xs text-amber-500 font-bold px-2.5 py-1 bg-amber-500/10 rounded-full border border-amber-500/20">
              Free Entry
            </span>
          </div>

          <div className="space-y-4">
            {events.map((event: EventItem) => (
              <div
                key={event.id}
                className="group flex flex-col sm:flex-row bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-xl transition-all hover:border-zinc-700"
              >
                <div className="sm:w-48 h-48 sm:h-auto relative overflow-hidden shrink-0 bg-zinc-950">
                  <img src={event.image} alt={event.title} className="w-full h-full object-cover group-hover:scale-105 transition duration-500" />
                  <div className="absolute top-2 left-2 px-2.5 py-0.5 rounded-md bg-zinc-950/80 backdrop-blur-md text-[10px] font-bold text-amber-400 uppercase tracking-wider border border-zinc-800">
                    {event.category}
                  </div>
                </div>

                <div className="p-5 sm:p-6 flex-1 flex flex-col justify-between space-y-3">
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2 text-xs font-bold text-amber-400">
                      <Calendar className="w-3.5 h-3.5" />
                      <span>{event.date} • {event.time}</span>
                    </div>
                    <h4 className="text-lg font-bold text-white group-hover:text-amber-400 transition-colors font-['Outfit']">
                      {event.title}
                    </h4>
                    <p className="text-xs text-zinc-300 leading-relaxed line-clamp-2">
                      {event.description}
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-zinc-800 text-xs">
                    <span className="text-zinc-400 font-medium">📍 {event.location}</span>
                    <button
                      onClick={() => {
                        window.open(`https://wa.me/${whatsappNumber}?text=Halo%20saya%20mau%20mendaftar%20event%20${event.title}`, '_blank');
                      }}
                      className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-amber-500 hover:text-zinc-950 text-zinc-200 font-bold transition cursor-pointer"
                    >
                      Join Event
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
