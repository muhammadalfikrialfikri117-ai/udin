import React, { useState, useMemo } from 'react';
import { Search, Sparkles, MessageCircle, Star, Filter, Coffee, Utensils, Cake } from 'lucide-react';
import { MenuItem } from '../data/coffeeData';
import { useApp } from '../context/AppContext';

export const DigitalMenu: React.FC = () => {
  const { data, addUserReview } = useApp();
  const menuItems = data.menuItems;
  const brand = data.brandInfo;
  const userReviews = data.userReviews || [];
  const whatsappNumber = (brand.whatsappPhone || '+628981125445').replace(/\D/g, '');

  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null);
  
  // Review form states
  const [reviewName, setReviewName] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [showReviewForm, setShowReviewForm] = useState(false);

  const categories = [
    { id: 'all', label: 'Semua 🍽️', icon: null },
    { id: 'drink', label: 'Minuman ☕', icon: <Coffee className="w-4 h-4" /> },
    { id: 'food', label: 'Makanan 🍛', icon: <Utensils className="w-4 h-4" /> },
    { id: 'snack', label: 'Camilan 🥐', icon: <Cake className="w-4 h-4" /> },
  ];

  const filteredItems = useMemo(() => {
    return menuItems.filter((item) => {
      const matchesCat = selectedCategory === 'all' || item.category === selectedCategory;
      const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            (item.tags && item.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase())));
      return matchesCat && matchesSearch;
    });
  }, [menuItems, selectedCategory, searchQuery]);

  const handleOrderWhatsApp = (item: MenuItem, notes: string = '') => {
    const text = `Halo ${brand.name}, saya mau pesan: %0A%0A*${item.name}* (${item.price})%0ACatatan: ${notes || 'Tanpa catatan'}%0A%0AMohon info ketersediaan dan total pembayarannya. Terima kasih!`;
    window.open(`https://wa.me/${whatsappNumber}?text=${text}`, '_blank');
  };

  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedItem || !reviewName || !reviewComment) return;

    addUserReview({
      itemId: selectedItem.id,
      userName: reviewName,
      rating: reviewRating,
      comment: reviewComment
    });

    setReviewName('');
    setReviewComment('');
    setReviewRating(5);
    setShowReviewForm(false);
    alert("Terima kasih! Ulasan Anda telah berhasil dikirim.");
  };

  const getItemReviews = (itemId: string) => {
    return userReviews.filter(rev => rev.itemId === itemId);
  };

  const calculateAverageRating = (item: MenuItem) => {
    const itemReviews = getItemReviews(item.id);
    if (itemReviews.length === 0) return item.rating || 5.0;
    const sum = itemReviews.reduce((acc, curr) => acc + curr.rating, 0);
    return (sum / itemReviews.length).toFixed(1);
  };

  const getTotalReviewCount = (item: MenuItem) => {
    const itemReviews = getItemReviews(item.id);
    return (item.reviewsCount || 0) + itemReviews.length;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10 animate-in fade-in duration-300">
      
      {/* Section Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 font-semibold text-xs uppercase tracking-wider">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Artisan & Crafted</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-['Outfit']">
          Digital Menu & Order Hub
        </h2>
        <p className="text-zinc-400 text-sm sm:text-base leading-relaxed">
          From legendary Gayo Arabica pour overs and traditional Kopi Saring to savory Balinese Sambal Matah chicken. Explore our fresh daily offerings.
        </p>
      </div>

      {/* Search & Category Filter Bar */}
      <div className="space-y-6">
        <div className="max-w-md mx-auto relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-400" />
          <input
            type="text"
            placeholder="Search coffee, pastries, matcha, sambal matah..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-zinc-900 border border-zinc-700/80 rounded-2xl pl-12 pr-4 py-3.5 text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 text-sm shadow-xl transition"
          />
          {searchQuery && (
            <button 
              onClick={() => setSearchQuery('')}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-xs text-zinc-400 hover:text-white bg-zinc-800 px-2 py-1 rounded-lg"
            >
              Clear
            </button>
          )}
        </div>

        {/* Filter Pills */}
        <div className="flex items-center justify-start sm:justify-center gap-2 overflow-x-auto pb-3 scrollbar-none">
          {categories.map((cat) => {
            const isActive = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm shrink-0 transition-all cursor-pointer ${
                  isActive
                    ? 'bg-amber-500 text-zinc-950 shadow-lg shadow-amber-500/20 scale-105'
                    : 'bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800 border border-zinc-800'
                }`}
              >
                {cat.icon && <span className={isActive ? 'text-zinc-950' : 'text-amber-500'}>{cat.icon}</span>}
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Item Grid */}
      {filteredItems.length === 0 ? (
        <div className="p-12 text-center bg-zinc-900 rounded-3xl border border-zinc-800 max-w-lg mx-auto">
          <Filter className="w-12 h-12 text-zinc-600 mx-auto mb-4 animate-bounce" />
          <h3 className="text-xl font-bold text-white mb-2">No menu items found</h3>
          <p className="text-zinc-400 text-sm mb-6">We couldn't find anything matching "{searchQuery}" in this category.</p>
          <button
            onClick={() => { setSelectedCategory('all'); setSearchQuery(''); }}
            className="px-6 py-2.5 bg-amber-500 text-zinc-950 font-bold rounded-xl text-sm"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="group flex flex-col rounded-3xl bg-zinc-900/90 border border-zinc-800 hover:border-amber-500/50 shadow-xl overflow-hidden transition-all duration-300 hover:-translate-y-1.5"
            >
              {/* Image Box */}
              <div className="relative h-56 w-full overflow-hidden bg-zinc-950">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-transparent to-transparent opacity-60"></div>
                
                {/* Badges */}
                <div className="absolute top-3 left-3 flex flex-wrap gap-1.5">
                  {item.isPopular && (
                    <span className="px-3 py-1 bg-amber-500 text-zinc-950 font-extrabold text-[10px] rounded-full uppercase tracking-wider shadow">
                      ★ Best Seller
                    </span>
                  )}
                  {item.isNew && (
                    <span className="px-3 py-1 bg-emerald-500 text-zinc-950 font-extrabold text-[10px] rounded-full uppercase tracking-wider shadow">
                      New
                    </span>
                  )}
                </div>

                {/* Rating badge */}
                <div className="absolute bottom-3 left-3 flex items-center gap-1 px-2.5 py-1 rounded-lg bg-zinc-950/80 backdrop-blur-md text-xs font-bold text-amber-400 border border-zinc-800 shadow-xl">
                  <Star className="w-3.5 h-3.5 fill-amber-400" />
                  <span>{calculateAverageRating(item)}</span>
                  <span className="text-zinc-400 font-normal">({getTotalReviewCount(item)})</span>
                </div>

                {/* Price tag */}
                <div className="absolute bottom-3 right-3 px-3 py-1 rounded-lg bg-amber-500 text-zinc-950 font-extrabold text-sm shadow-md">
                  {item.price}
                </div>
              </div>

              {/* Text / Actions content */}
              <div className="flex-1 p-6 flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <h3 className="text-xl font-bold text-white group-hover:text-amber-400 transition-colors font-['Outfit']">
                    {item.name}
                  </h3>
                  <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed line-clamp-2">
                    {item.description}
                  </p>
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {item.tags && item.tags.map((tag, idx) => (
                      <span key={idx} className="text-[10px] px-2 py-0.5 rounded-md bg-zinc-800 text-zinc-300 border border-zinc-700/60">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-2 border-t border-zinc-800/80 flex items-center gap-3">
                  <button
                    onClick={() => setSelectedItem(item)}
                    className="flex-1 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-bold transition text-center cursor-pointer"
                  >
                    View Details
                  </button>

                  <button
                    onClick={() => handleOrderWhatsApp(item)}
                    className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:opacity-90 text-white text-xs font-bold shadow-md shadow-emerald-950 flex items-center justify-center gap-1.5 transition cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Order WA</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Item Details / Customizer Modal */}
      {selectedItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-xl bg-zinc-900 border border-zinc-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            
            {/* Modal Header Image */}
            <div className="relative h-48 sm:h-64 shrink-0 overflow-hidden bg-zinc-950">
              <img src={selectedItem.image} alt={selectedItem.name} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-transparent to-transparent"></div>
              <button
                onClick={() => { setSelectedItem(null); setShowReviewForm(false); }}
                className="absolute top-4 right-4 p-2 rounded-full bg-zinc-950/80 text-zinc-400 hover:text-white cursor-pointer z-10"
              >
                ✕
              </button>
            </div>

            {/* Scrollable Modal Content */}
            <div className="flex-1 overflow-y-auto p-6 sm:p-8 space-y-8 scrollbar-thin scrollbar-thumb-zinc-700">
              <div className="space-y-4">
                <div className="flex items-center justify-between gap-4">
                  <h3 className="text-2xl font-extrabold text-white font-['Outfit']">{selectedItem.name}</h3>
                  <span className="px-3 py-1 rounded-lg bg-amber-500 text-zinc-950 font-extrabold text-base shrink-0">
                    {selectedItem.price}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                    <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                    <span className="text-sm font-bold text-amber-400">{calculateAverageRating(selectedItem)}</span>
                  </div>
                  <span className="text-xs text-zinc-400">({getTotalReviewCount(selectedItem)} ulasan pengunjung)</span>
                </div>
                <p className="text-sm text-zinc-300 leading-relaxed">
                  {selectedItem.description}
                </p>
              </div>

              {/* Order via WA Section */}
              <div className="p-5 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-4 shadow-inner">
                <div>
                  <label className="block text-xs font-bold text-zinc-400 uppercase tracking-wider mb-2">
                    Catatan Pesanan (Contoh: Gula dikit, es banyak)
                  </label>
                  <input
                    id="order-notes-input"
                    type="text"
                    placeholder="Masukkan instruksi khusus..."
                    className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
                  />
                </div>
                <button
                  onClick={() => {
                    const notesEl = document.getElementById('order-notes-input') as HTMLInputElement;
                    handleOrderWhatsApp(selectedItem, notesEl?.value);
                  }}
                  className="w-full py-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:opacity-95 text-white font-extrabold text-sm shadow-xl flex items-center justify-center gap-2 transition cursor-pointer"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span>Pesan Sekarang via WhatsApp</span>
                </button>
              </div>

              {/* Reviews Section */}
              <div className="space-y-6">
                <div className="flex items-center justify-between border-t border-zinc-800 pt-6">
                  <h4 className="text-lg font-bold text-white font-['Outfit']">Ulasan & Artikel Pengunjung</h4>
                  {!showReviewForm && (
                    <button 
                      onClick={() => setShowReviewForm(true)}
                      className="text-xs font-bold text-amber-500 hover:underline cursor-pointer"
                    >
                      + Beri Ulasan
                    </button>
                  )}
                </div>

                {/* Review Form */}
                {showReviewForm && (
                  <form onSubmit={handleAddReview} className="p-5 rounded-2xl bg-amber-500/5 border border-amber-500/20 space-y-4 animate-in slide-in-from-top-4 duration-300">
                    <div className="flex items-center justify-between">
                      <h5 className="text-xs font-bold text-amber-500 uppercase tracking-widest">Tulis Ulasan Anda</h5>
                      <div className="flex items-center gap-1">
                        {[1, 2, 3, 4, 5].map((num) => (
                          <button
                            key={num}
                            type="button"
                            onClick={() => setReviewRating(num)}
                            className="cursor-pointer"
                          >
                            <Star className={`w-5 h-5 ${num <= reviewRating ? 'fill-amber-500 text-amber-500' : 'text-zinc-700'}`} />
                          </button>
                        ))}
                      </div>
                    </div>
                    
                    <input
                      type="text"
                      required
                      placeholder="Nama Anda"
                      value={reviewName}
                      onChange={e => setReviewName(e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500"
                    />

                    <textarea
                      required
                      rows={3}
                      placeholder="Berikan pendapat Anda tentang menu ini atau tulis ulasan singkat..."
                      value={reviewComment}
                      onChange={e => setReviewComment(e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500"
                    />

                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setShowReviewForm(false)}
                        className="flex-1 py-2.5 rounded-xl bg-zinc-800 text-zinc-400 font-bold text-xs"
                      >
                        Batal
                      </button>
                      <button
                        type="submit"
                        className="flex-2 py-2.5 rounded-xl bg-amber-500 text-zinc-950 font-extrabold text-xs shadow-lg"
                      >
                        Kirim Ulasan
                      </button>
                    </div>
                  </form>
                )}

                {/* Reviews List */}
                <div className="space-y-4">
                  {getItemReviews(selectedItem.id).length === 0 ? (
                    <div className="text-center py-8">
                      <p className="text-zinc-500 text-sm italic">Belum ada ulasan untuk menu ini. Jadi yang pertama mengulas!</p>
                    </div>
                  ) : (
                    getItemReviews(selectedItem.id).map((rev) => (
                      <div key={rev.id} className="bg-zinc-900/50 p-4 rounded-2xl border border-zinc-800/50 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-white text-sm">{rev.userName}</span>
                          <span className="text-[10px] text-zinc-500">{rev.date}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          {[...Array(5)].map((_, i) => (
                            <Star key={i} className={`w-3 h-3 ${i < rev.rating ? 'fill-amber-500 text-amber-500' : 'text-zinc-800'}`} />
                          ))}
                        </div>
                        <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed italic">
                          "{rev.comment}"
                        </p>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            {/* Modal Footer (Sticky) */}
            <div className="p-6 border-t border-zinc-800 bg-zinc-900 shrink-0">
              <button
                onClick={() => { setSelectedItem(null); setShowReviewForm(false); }}
                className="w-full py-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold text-sm transition cursor-pointer"
              >
                Kembali ke Daftar Menu
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
