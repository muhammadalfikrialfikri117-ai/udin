import React from 'react';
import { CheckCircle2, Clock, MapPin, Sparkles, MessageCircle, Globe } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface HeroProps {
  setActiveTab: (tab: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ setActiveTab }) => {
  const { data } = useApp();
  const brand = data.brandInfo;
  const whatsappNumber = (brand.whatsappPhone || '+628981125445').replace(/\D/g, '');

  return (
    <div className="relative pt-12 pb-8 overflow-hidden">
      {/* Background ambient glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-b from-amber-500/10 via-orange-600/5 to-transparent blur-3xl pointer-events-none -z-10"></div>
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
        
        {/* Profile Avatar with story ring effect */}
        <div className="relative inline-block mb-6">
          <div className="absolute -inset-2 rounded-full bg-gradient-to-tr from-amber-500 via-orange-500 to-amber-200 animate-spin-slow opacity-80 blur-[2px]"></div>
          <div className="relative p-1.5 bg-zinc-950 rounded-full">
            <img
              src={brand.logo || "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?q=80&w=400&auto=format&fit=crop"}
              alt={brand.name}
              className="w-28 h-28 sm:w-32 sm:h-32 rounded-full object-cover border-2 border-zinc-800 shadow-2xl"
            />
          </div>
          {/* Verified Check */}
          <div className="absolute bottom-1 right-2 bg-zinc-950 p-1 rounded-full text-amber-500 shadow-lg border border-zinc-800">
            <CheckCircle2 className="w-6 h-6 fill-amber-500 text-zinc-950" />
          </div>
        </div>

        {/* Brand Name & Handle */}
        <div className="flex items-center justify-center gap-2 mb-1">
          <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white font-['Outfit']">
            {brand.name}
          </h1>
        </div>
        <a
          href={brand.instagramUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 text-amber-400 hover:text-amber-300 font-semibold text-sm sm:text-base mb-4 bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20 transition cursor-pointer"
        >
          <Globe className="w-4 h-4" />
          <span>{brand.handle || '@starblackcoffee.id'}</span>
        </a>

        {/* Tagline */}
        <p className="text-zinc-300 text-base sm:text-lg max-w-2xl mx-auto font-medium leading-relaxed mb-6">
          {brand.tagline}
        </p>

        {/* Quick Info Pills */}
        <div className="flex flex-wrap items-center justify-center gap-3 mb-8 text-xs sm:text-sm">
          <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-medium shadow-sm">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>{brand.hours}</span>
          </div>

          <div 
            onClick={() => setActiveTab('locations')}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-zinc-900/90 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 font-medium transition cursor-pointer"
          >
            <MapPin className="w-4 h-4 text-amber-500" />
            <span>Kandangan Kota & Bireuen</span>
          </div>

          <div 
            onClick={() => setActiveTab('coworking')}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-zinc-900/90 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 font-medium transition cursor-pointer"
          >
            <Clock className="w-4 h-4 text-amber-500" />
            <span>Co-Working & Wi-Fi Ready</span>
          </div>
        </div>

        {/* Fast Action CTA Row */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 max-w-md mx-auto">
          <a
            href={`https://wa.me/${whatsappNumber}?text=Halo%20${encodeURIComponent(brand.name)},%20saya%20ingin%20pesan/reservasi.`}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto flex-1 flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-bold text-sm shadow-xl shadow-emerald-950 hover:opacity-95 transition"
          >
            <MessageCircle className="w-5 h-5" />
            <span>Order via WhatsApp</span>
          </a>

          <button
            onClick={() => setActiveTab('menu')}
            className="w-full sm:w-auto flex-1 flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 text-white font-bold text-sm shadow-xl shadow-orange-950 hover:opacity-95 transition cursor-pointer"
          >
            <Sparkles className="w-5 h-5" />
            <span>Explore Full Menu</span>
          </button>
        </div>

      </div>
    </div>
  );
};
