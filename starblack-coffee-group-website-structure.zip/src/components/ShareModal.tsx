import React, { useState } from 'react';
import { Copy, Check, Share2, X, ExternalLink, QrCode } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose }) => {
  const { data } = useApp();
  const brand = data.brandInfo;
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const shareUrl = "https://linktr.ee/starblackcoffeegroup";

  const handleCopy = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: brand.name,
          text: brand.tagline,
          url: shareUrl,
        });
      } catch (err) {
        console.log("Share failed:", err);
      }
    } else {
      handleCopy();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 text-center">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-zinc-800/80 hover:bg-zinc-700 text-zinc-400 hover:text-white transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="space-y-2">
          <div className="mx-auto w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-500 flex items-center justify-center mb-3">
            <QrCode className="w-6 h-6 animate-pulse" />
          </div>
          <h3 className="text-2xl font-extrabold text-white font-['Outfit']">Share Starblack Portal</h3>
          <p className="text-xs text-zinc-400 max-w-xs mx-auto">
            Scan QR code or copy the official link below to share with your friends and community.
          </p>
        </div>

        {/* QR Code Graphic Placeholder */}
        <div className="bg-white p-6 rounded-2xl inline-block shadow-lg mx-auto border-4 border-amber-500/30">
          <div className="w-48 h-48 bg-zinc-950 flex flex-col items-center justify-center rounded-xl p-4 text-center relative overflow-hidden">
            <div className="absolute inset-0 bg-[radial-gradient(#d97706_1px,transparent_1px)] [background-size:12px_12px] opacity-40"></div>
            <div className="relative z-10 space-y-2 flex flex-col items-center">
              {brand.logo ? (
                <img src={brand.logo} alt="Logo" className="w-12 h-12 rounded-lg object-cover border border-amber-500/50 mb-1" />
              ) : (
                <span className="text-amber-500 font-extrabold text-xl tracking-wider font-['Outfit']">{brand.name.split(' ')[0]}</span>
              )}
              <div className="w-20 h-20 bg-white mx-auto rounded-lg p-2 flex items-center justify-center shadow">
                <span className="text-zinc-950 font-black text-[10px] uppercase tracking-tighter">SCAN ME</span>
              </div>
              <span className="text-[9px] text-zinc-400 block tracking-widest mt-1">STARBLACK PORTAL</span>
            </div>
          </div>
        </div>

        {/* Copy Box */}
        <div className="flex items-center gap-2 p-2 rounded-xl bg-zinc-950 border border-zinc-800">
          <input
            type="text"
            readOnly
            value={shareUrl}
            className="bg-transparent text-xs text-zinc-300 px-3 py-2 flex-1 focus:outline-none truncate font-mono"
          />
          <button
            onClick={handleCopy}
            className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${
              copied ? 'bg-emerald-600 text-white' : 'bg-amber-500 hover:bg-amber-400 text-zinc-950 font-extrabold'
            }`}
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copied!' : 'Copy'}</span>
          </button>
        </div>

        {/* Native share CTA */}
        <button
          onClick={handleNativeShare}
          className="w-full py-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold text-sm flex items-center justify-center gap-2 transition cursor-pointer"
        >
          <Share2 className="w-4 h-4 text-amber-400" />
          <span>Share via Native Device Apps</span>
        </button>

        <div className="pt-2">
          <a
            href={shareUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs text-amber-400 hover:underline flex items-center justify-center gap-1"
          >
            <span>Open Linktree directly</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>

      </div>
    </div>
  );
};
