import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Settings, Plus, Trash2, Edit2, Check, RefreshCw, Upload, 
  Coffee, Link as LinkIcon, ShoppingBag, ShieldCheck, Lock, Unlock, AlertTriangle, MessageCircle, Star
} from 'lucide-react';
import { MenuItem, LinkItem } from '../data/coffeeData';

export const AdminPanel: React.FC = () => {
  const { 
    data, 
    isAdmin, 
    setIsAdmin, 
    updateBrandInfo, 
    addMenuItem, 
    updateMenuItem, 
    deleteMenuItem,
    addQuickLink,
    updateQuickLink,
    deleteQuickLink,
    addMerchItem,
    updateMerchItem,
    deleteMerchItem,
    deleteUserReview,
    changeAdminPin,
    resetToDefaults 
  } = useApp();

  const [activeTab, setActiveTab] = useState<'menu' | 'links' | 'brand' | 'merch' | 'reviews' | 'security'>('menu');
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState(false);

  // States for Security (PIN Change)
  const [securityForm, setSecurityForm] = useState({
    currentPin: '',
    newPin: '',
    confirmPin: ''
  });
  const [securityMsg, setSecurityFormMsg] = useState({ text: '', type: 'error' });

  // States for Editing / Adding Menu Item
  const [editingMenuId, setEditingMenuId] = useState<string | null>(null);
  const [isAddingMenu, setIsAddingMenu] = useState(false);
  const [menuForm, setMenuForm] = useState({
    name: '',
    category: 'drink' as MenuItem['category'],
    price: 'Rp 28.000',
    priceNum: 28000,
    description: '',
    image: '',
    tags: 'Best Seller, Favorite',
    isPopular: false,
    isNew: false,
  });

  // States for Editing / Adding Quick Link
  const [editingLinkId, setEditingLinkId] = useState<string | null>(null);
  const [isAddingLink, setIsAddingLink] = useState(false);
  const [linkForm, setLinkForm] = useState({
    title: '',
    subtitle: '',
    iconName: 'MessageCircle',
    url: '',
    badge: '',
    category: 'order' as LinkItem['category']
  });

  // States for Brand Info form
  const [brandForm, setBrandForm] = useState({ ...data.brandInfo });

  // States for Merch Item
  const [editingMerchId, setEditingMerchId] = useState<string | null>(null);
  const [isAddingMerch, setIsAddingMerch] = useState(false);
  const [merchForm, setMerchForm] = useState({
    name: '',
    price: 'Rp 100.000',
    desc: '',
    image: ''
  });

  // PIN check for Admin Simulation
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Basic Sanitization: Remove extra spaces and special characters from PIN input
    const sanitizedInput = pinInput.trim();
    
    if (sanitizedInput === data.adminPin) {
      setIsAdmin(true);
      setPinError(false);
      setPinInput('');
    } else {
      setPinError(true);
    }
  };

  const handleUpdatePin = (e: React.FormEvent) => {
    e.preventDefault();
    if (securityForm.currentPin !== data.adminPin) {
      setSecurityFormMsg({ text: 'PIN Lama salah!', type: 'error' });
      return;
    }
    if (securityForm.newPin.length < 4) {
      setSecurityFormMsg({ text: 'PIN Baru minimal 4 karakter!', type: 'error' });
      return;
    }
    if (securityForm.newPin !== securityForm.confirmPin) {
      setSecurityFormMsg({ text: 'Konfirmasi PIN tidak cocok!', type: 'error' });
      return;
    }

    changeAdminPin(securityForm.newPin);
    setSecurityFormMsg({ text: 'PIN berhasil diperbarui!', type: 'success' });
    setSecurityForm({ currentPin: '', newPin: '', confirmPin: '' });
    
    // Auto logout for security after PIN change
    setTimeout(() => {
      setIsAdmin(false);
      setSecurityFormMsg({ text: '', type: 'error' });
    }, 2000);
  };

  // Helper to convert uploaded file to Base64
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, callback: (base64Url: string) => void) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) { // 2MB limit
        alert("Ukuran gambar terlalu besar. Maksimal 2MB untuk menjaga kecepatan web.");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          callback(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // --- Menu Item Handlers ---
  const handleStartAddMenu = (category: MenuItem['category'] = 'drink') => {
    setIsAddingMenu(true);
    setEditingMenuId(null);
    setMenuForm({
      name: '',
      category: category,
      price: category === 'drink' ? 'Rp 25.000' : category === 'food' ? 'Rp 40.000' : 'Rp 28.000',
      priceNum: category === 'drink' ? 25000 : category === 'food' ? 40000 : 28000,
      description: '',
      image: category === 'drink' 
        ? 'https://images.unsplash.com/photo-1541167760496-1628856ab772?q=80&w=800&auto=format&fit=crop'
        : category === 'food'
        ? 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?q=80&w=800&auto=format&fit=crop'
        : 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?q=80&w=800&auto=format&fit=crop',
      tags: 'Fresh, Crafted',
      isPopular: false,
      isNew: true,
    });
    // Scroll smoothly to form
    setTimeout(() => {
      document.getElementById('menu-form-box')?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  const handleStartEditMenu = (item: MenuItem) => {
    setIsAddingMenu(false);
    setEditingMenuId(item.id);
    setMenuForm({
      name: item.name,
      category: item.category,
      price: item.price,
      priceNum: item.priceNum,
      description: item.description,
      image: item.image,
      tags: item.tags.join(', '),
      isPopular: !!item.isPopular,
      isNew: !!item.isNew,
    });
  };

  const handleSaveMenu = (e: React.FormEvent) => {
    e.preventDefault();
    if (!menuForm.name || !menuForm.price) {
      alert("Nama dan Harga wajib diisi!");
      return;
    }

    const payload = {
      name: menuForm.name,
      category: menuForm.category,
      price: menuForm.price,
      priceNum: parseInt(menuForm.price.replace(/\D/g, '')) || 25000,
      description: menuForm.description || 'Premium coffee offering from Starblack.',
      rating: 4.9,
      reviewsCount: Math.floor(Math.random() * 200) + 50,
      image: menuForm.image || 'https://images.unsplash.com/photo-1541167760496-1628856ab772?q=80&w=800&auto=format&fit=crop',
      tags: menuForm.tags.split(',').map(t => t.trim()).filter(Boolean),
      isPopular: menuForm.isPopular,
      isNew: menuForm.isNew,
    };

    if (isAddingMenu) {
      addMenuItem(payload);
      alert("Menu baru berhasil ditambahkan!");
    } else if (editingMenuId) {
      updateMenuItem(editingMenuId, payload);
      alert("Menu berhasil diperbarui!");
    }

    setIsAddingMenu(false);
    setEditingMenuId(null);
  };

  // --- Quick Link Handlers ---
  const handleStartAddLink = () => {
    setIsAddingLink(true);
    setEditingLinkId(null);
    setLinkForm({
      title: '',
      subtitle: '',
      iconName: 'MessageCircle',
      url: 'https://',
      badge: 'New Link',
      category: 'order'
    });
  };

  const handleStartEditLink = (link: LinkItem) => {
    setIsAddingLink(false);
    setEditingLinkId(link.id);
    setLinkForm({
      title: link.title,
      subtitle: link.subtitle,
      iconName: link.iconName,
      url: link.url,
      badge: link.badge || '',
      category: link.category || 'order'
    });
  };

  const handleSaveLink = (e: React.FormEvent) => {
    e.preventDefault();
    if (!linkForm.title || !linkForm.url) {
      alert("Judul link dan URL wajib diisi!");
      return;
    }

    const payload: Omit<LinkItem, 'id'> = {
      title: linkForm.title,
      subtitle: linkForm.subtitle,
      iconName: linkForm.iconName,
      url: linkForm.url,
      badge: linkForm.badge || undefined,
      category: linkForm.category,
      isFeatured: linkForm.category === 'order'
    };

    if (isAddingLink) {
      addQuickLink(payload);
      alert("Link baru berhasil ditambahkan!");
    } else if (editingLinkId) {
      updateQuickLink(editingLinkId, payload);
      alert("Link berhasil diperbarui!");
    }

    setIsAddingLink(false);
    setEditingLinkId(null);
  };

  // --- Merch Handlers ---
  const handleStartAddMerch = () => {
    setIsAddingMerch(true);
    setEditingMerchId(null);
    setMerchForm({
      name: '',
      price: 'Rp 150.000',
      desc: '',
      image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?q=80&w=800&auto=format&fit=crop'
    });
  };

  const handleStartEditMerch = (item: any) => {
    setIsAddingMerch(false);
    setEditingMerchId(item.id);
    setMerchForm({
      name: item.name,
      price: item.price,
      desc: item.desc,
      image: item.image
    });
  };

  const handleSaveMerch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!merchForm.name || !merchForm.price) return;
    if (isAddingMerch) {
      addMerchItem(merchForm);
    } else if (editingMerchId) {
      updateMerchItem(editingMerchId, merchForm);
    }
    setIsAddingMerch(false);
    setEditingMerchId(null);
  };

  const handleSaveBrand = (e: React.FormEvent) => {
    e.preventDefault();
    updateBrandInfo(brandForm);
    alert("Informasi utama brand berhasil disimpan!");
  };

  // If user is not authenticated as Admin yet
  if (!isAdmin) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center space-y-6">
        <div className="mx-auto w-16 h-16 bg-amber-500/10 border border-amber-500/30 rounded-2xl flex items-center justify-center text-amber-500 shadow-xl">
          <Lock className="w-8 h-8" />
        </div>
        <div className="space-y-2">
          <h2 className="text-3xl font-extrabold text-white font-['Outfit']">Login Admin</h2>
          <p className="text-sm text-zinc-400">
            Akses dibatasi. Masukkan PIN keamanan untuk mengelola website Starblack.
          </p>
        </div>

        <form onSubmit={handleLogin} className="space-y-4">
          <input
            type="password"
            placeholder="••••"
            value={pinInput}
            onChange={(e) => setPinInput(e.target.value)}
            className="w-full text-center text-2xl tracking-widest font-mono bg-zinc-900 border border-zinc-700 focus:border-amber-500 rounded-2xl py-4 text-white focus:outline-none shadow-inner"
            autoFocus
          />
          {pinError && (
            <p className="text-xs font-bold text-red-500 flex items-center justify-center gap-1">
              <AlertTriangle className="w-4 h-4" />
              <span>PIN salah! Silakan coba lagi.</span>
            </p>
          )}
          <button
            type="submit"
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-600 font-bold text-zinc-950 shadow-xl hover:opacity-95 transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <Unlock className="w-5 h-5 text-zinc-950" />
            <span>Buka Kunci Admin</span>
          </button>
        </form>
      </div>
    );
  }

  // Admin Dashboard View
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-300 overflow-x-hidden">
      
      {/* Admin Top Banner - Perbaikan layout agar tombol tidak keluar jalur */}
      <div className="bg-zinc-900 border border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl overflow-hidden">
        <div className="flex flex-col lg:flex-row items-center lg:items-start justify-between gap-8">
          
          {/* Left Info Column */}
          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 text-center sm:text-left">
            <div className="p-4 bg-amber-500/10 rounded-2xl border border-amber-500/30 text-amber-500 shrink-0">
              <Settings className="w-8 h-8 animate-spin-slow" />
            </div>
            <div className="space-y-2">
              <div className="flex flex-col sm:flex-row items-center gap-3">
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-['Outfit']">Admin Control Center</h2>
                <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                  <span className="text-[10px] font-extrabold text-emerald-500 uppercase tracking-widest">LIVE EDIT</span>
                </div>
              </div>
              <p className="text-xs sm:text-sm text-zinc-400 max-w-xl leading-relaxed">
                Setiap perubahan yang Anda simpan di sini akan langsung tampil seketika di website tanpa perlu reload. Kelola menu, link bio, dan informasi kontak dengan mudah.
              </p>
            </div>
          </div>

          {/* Right Action Column - Perbaikan tombol agar tidak overflow */}
          <div className="flex flex-row sm:flex-row lg:flex-col items-stretch gap-3 w-full lg:w-auto min-w-[180px]">
            <button
              onClick={resetToDefaults}
              className="flex-1 px-4 py-3 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer whitespace-nowrap"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Reset Data</span>
            </button>
            <button
              onClick={() => setIsAdmin(false)}
              className="flex-1 px-4 py-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold text-xs flex items-center justify-center gap-2 border border-zinc-700 transition cursor-pointer whitespace-nowrap"
            >
              <Lock className="w-4 h-4 text-amber-400" />
              <span>Keluar Admin</span>
            </button>
          </div>
        </div>
      </div>

      {/* Admin Section Tabs - Perbaikan scrollbar agar lebih rapi */}
      <div className="relative">
        <div className="flex items-center gap-2 bg-zinc-900 p-1.5 rounded-2xl border border-zinc-800 overflow-x-auto scrollbar-thin scrollbar-thumb-zinc-700 scrollbar-track-transparent">
          <button
            onClick={() => { setActiveTab('menu'); setIsAddingMenu(false); setEditingMenuId(null); }}
            className={`flex items-center gap-2 px-5 py-3 rounded-xl font-bold text-xs sm:text-sm shrink-0 transition cursor-pointer whitespace-nowrap ${
              activeTab === 'menu' ? 'bg-amber-500 text-zinc-950 shadow-lg' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Coffee className="w-4 h-4" />
            <span>Daftar Menu ({data.menuItems.length})</span>
          </button>

          <button
            onClick={() => { setActiveTab('links'); setIsAddingLink(false); setEditingLinkId(null); }}
            className={`flex items-center gap-2 px-5 py-3 rounded-xl font-bold text-xs sm:text-sm shrink-0 transition cursor-pointer whitespace-nowrap ${
              activeTab === 'links' ? 'bg-amber-500 text-zinc-950 shadow-lg' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <LinkIcon className="w-4 h-4" />
            <span>Link Bio ({data.quickLinks.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('brand')}
            className={`flex items-center gap-2 px-5 py-3 rounded-xl font-bold text-xs sm:text-sm shrink-0 transition cursor-pointer whitespace-nowrap ${
              activeTab === 'brand' ? 'bg-amber-500 text-zinc-950 shadow-lg' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Brand & WhatsApp</span>
          </button>

        <button
          onClick={() => { setActiveTab('merch'); setIsAddingMerch(false); setEditingMerchId(null); }}
          className={`flex items-center gap-2 px-5 py-3 rounded-xl font-bold text-xs sm:text-sm shrink-0 transition cursor-pointer whitespace-nowrap ${
            activeTab === 'merch' ? 'bg-amber-500 text-zinc-950 shadow-lg' : 'text-zinc-400 hover:text-white'
          }`}
        >
          <ShoppingBag className="w-4 h-4" />
          <span>Merchandise ({data.merch.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('reviews')}
          className={`flex items-center gap-2 px-5 py-3 rounded-xl font-bold text-xs sm:text-sm shrink-0 transition cursor-pointer whitespace-nowrap ${
            activeTab === 'reviews' ? 'bg-amber-500 text-zinc-950 shadow-lg' : 'text-zinc-400 hover:text-white'
          }`}
        >
          <MessageCircle className="w-4 h-4" />
          <span>Ulasan Pembeli ({data.userReviews.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('security')}
          className={`flex items-center gap-2 px-5 py-3 rounded-xl font-bold text-xs sm:text-sm shrink-0 transition cursor-pointer whitespace-nowrap ${
            activeTab === 'security' ? 'bg-amber-500 text-zinc-950 shadow-lg' : 'text-zinc-400 hover:text-white'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          <span>Keamanan & PIN</span>
        </button>
      </div>
      </div>

      {/* --- TAB CONTENT 1: MENU ITEMS --- */}
      {activeTab === 'menu' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <h3 className="text-xl font-extrabold text-white font-['Outfit']">Manajemen Menu Starblack</h3>
            {!isAddingMenu && !editingMenuId && (
              <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                <button
                  onClick={() => handleStartAddMenu('drink')}
                  className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-amber-500 text-zinc-950 font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg hover:scale-[1.02] active:scale-95 transition cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ Minuman</span>
                </button>
                <button
                  onClick={() => handleStartAddMenu('food')}
                  className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-emerald-500 text-zinc-950 font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg hover:scale-[1.02] active:scale-95 transition cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ Makanan</span>
                </button>
                <button
                  onClick={() => handleStartAddMenu('snack')}
                  className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-orange-500 text-zinc-950 font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg hover:scale-[1.02] active:scale-95 transition cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ Camilan</span>
                </button>
              </div>
            )}
          </div>

          {/* Form Tambah/Edit Menu */}
          {(isAddingMenu || editingMenuId) && (
            <div id="menu-form-box" className="bg-zinc-900 border-2 border-amber-500 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 animate-in zoom-in-95 duration-200">
              <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
                <h4 className="text-xl font-bold text-white font-['Outfit'] flex items-center gap-2">
                  <Coffee className="w-5 h-5 text-amber-500" />
                  <span>{isAddingMenu ? 'Tambah Menu Kopi / Makanan Baru' : `Edit Menu: ${menuForm.name}`}</span>
                </h4>
                <button
                  onClick={() => { setIsAddingMenu(false); setEditingMenuId(null); }}
                  className="px-4 py-2 rounded-lg bg-zinc-800 text-zinc-400 hover:text-white text-xs font-bold cursor-pointer"
                >
                  Batal
                </button>
              </div>

              <form onSubmit={handleSaveMenu} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  {/* Nama Item */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-zinc-300 uppercase">Nama Menu *</label>
                    <input
                      type="text"
                      required
                      placeholder="Contoh: Palm Sugar Aren Latte Premium"
                      value={menuForm.name}
                      onChange={e => setMenuForm({...menuForm, name: e.target.value})}
                      className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  {/* Kategori */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-zinc-300 uppercase">Kategori *</label>
                    <select
                      value={menuForm.category}
                      onChange={e => setMenuForm({...menuForm, category: e.target.value as any})}
                      className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-amber-500"
                    >
                      <option value="drink">Minuman (Coffee & Non-Coffee) ☕</option>
                      <option value="food">Makanan (Main Course) 🍛</option>
                      <option value="snack">Camilan (Snack & Pastry) 🥐</option>
                    </select>
                  </div>

                  {/* Harga */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-zinc-300 uppercase">Harga Display *</label>
                    <input
                      type="text"
                      required
                      placeholder="Contoh: Rp 28.000"
                      value={menuForm.price}
                      onChange={e => setMenuForm({...menuForm, price: e.target.value})}
                      className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  {/* Tags */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-zinc-300 uppercase">Label / Tags (Pemisah Koma)</label>
                    <input
                      type="text"
                      placeholder="Contoh: Best Seller, Iced/Hot, Creamy"
                      value={menuForm.tags}
                      onChange={e => setMenuForm({...menuForm, tags: e.target.value})}
                      className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>

                {/* Upload Foto & Link Foto */}
                <div className="space-y-3 p-4 rounded-2xl bg-zinc-950 border border-zinc-800">
                  <label className="block text-xs font-bold text-amber-400 uppercase">Foto Produk (Bisa Upload Langsung / Ganti URL)</label>
                  
                  <div className="flex flex-col sm:flex-row items-center gap-4">
                    {/* Preview Image */}
                    {menuForm.image && (
                      <img src={menuForm.image} alt="Preview" className="w-24 h-24 object-cover rounded-xl border border-amber-500 shadow" />
                    )}

                    <div className="flex-1 w-full space-y-3">
                      <div className="relative">
                        <input
                          type="file"
                          accept="image/*"
                          id="menu-photo-upload"
                          onChange={e => handleImageUpload(e, base64 => setMenuForm({...menuForm, image: base64}))}
                          className="hidden"
                        />
                        <label
                          htmlFor="menu-photo-upload"
                          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs cursor-pointer border border-zinc-700 shadow"
                        >
                          <Upload className="w-4 h-4 text-amber-500" />
                          <span>Pilih Foto dari Perangkat / HP</span>
                        </label>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-xs text-zinc-500">Atau masukkan URL Foto:</span>
                        <input
                          type="url"
                          placeholder="https://images.unsplash.com/..."
                          value={menuForm.image}
                          onChange={e => setMenuForm({...menuForm, image: e.target.value})}
                          className="flex-1 bg-zinc-900 border border-zinc-700 rounded-xl px-3 py-1.5 text-xs text-zinc-300 focus:outline-none focus:border-amber-500"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Deskripsi Produk */}
                <div className="space-y-2">
                  <label className="block text-xs font-bold text-zinc-300 uppercase">Deskripsi Produk</label>
                  <textarea
                    rows={3}
                    placeholder="Deskripsikan cita rasa kopi atau bahan premium masakan..."
                    value={menuForm.description}
                    onChange={e => setMenuForm({...menuForm, description: e.target.value})}
                    className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-amber-500"
                  />
                </div>

                {/* Badges Toggles */}
                <div className="flex flex-wrap items-center gap-6 pt-2">
                  <label className="flex items-center gap-2 text-sm text-zinc-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={menuForm.isPopular}
                      onChange={e => setMenuForm({...menuForm, isPopular: e.target.checked})}
                      className="w-5 h-5 rounded accent-amber-500"
                    />
                    <span className="font-bold">★ Tandai sebagai Best Seller</span>
                  </label>

                  <label className="flex items-center gap-2 text-sm text-zinc-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={menuForm.isNew}
                      onChange={e => setMenuForm({...menuForm, isNew: e.target.checked})}
                      className="w-5 h-5 rounded accent-emerald-500"
                    />
                    <span className="font-bold">Tandai sebagai Menu Baru (New)</span>
                  </label>
                </div>

                {/* Action Submit */}
                <div className="flex items-center gap-4 pt-4 border-t border-zinc-800">
                  <button
                    type="submit"
                    className="flex-1 py-4 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 font-extrabold text-zinc-950 text-sm shadow-xl hover:opacity-95 flex items-center justify-center gap-2 cursor-pointer active:scale-[0.98] transition"
                  >
                    <Check className="w-5 h-5 text-zinc-950" />
                    <span>Simpan Menu ke Website</span>
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* List Menu Terpisah per Kategori */}
          {(['drink', 'food', 'snack'] as const).map((cat) => {
            const items = data.menuItems.filter(i => i.category === cat);
            const catLabel = cat === 'drink' ? '☕ MINUMAN' : cat === 'food' ? '🍛 MAKANAN' : '🥐 CAMILAN';
            
            return (
              <div key={cat} className="space-y-4">
                <div className="flex items-center justify-between gap-3">
                  <div className="h-px flex-1 bg-zinc-800"></div>
                  <h4 className="text-sm font-black text-amber-500 tracking-[0.2em]">{catLabel} ({items.length})</h4>
                  <div className="h-px flex-1 bg-zinc-800"></div>
                  {!isAddingMenu && !editingMenuId && (
                    <button 
                      onClick={() => handleStartAddMenu(cat)}
                      className="px-3 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[10px] font-bold uppercase tracking-wider transition cursor-pointer"
                    >
                      + Tambah
                    </button>
                  )}
                </div>

                {items.length === 0 ? (
                  <div className="p-8 text-center border-2 border-dashed border-zinc-800 rounded-3xl group">
                    <p className="text-zinc-500 text-sm italic mb-3">Belum ada item di kategori {catLabel.toLowerCase()}.</p>
                    <button 
                      onClick={() => handleStartAddMenu(cat)}
                      className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-amber-500 hover:text-zinc-950 text-zinc-400 text-xs font-bold transition cursor-pointer"
                    >
                      Mulai Tambah {cat === 'drink' ? 'Minuman' : cat === 'food' ? 'Makanan' : 'Camilan'}
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {items.map(item => (
                      <div key={item.id} className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-lg flex flex-col justify-between group">
                        <div className="relative h-44 bg-zinc-950 overflow-hidden">
                          <img src={item.image} alt={item.name} className="w-full h-full object-cover group-hover:scale-105 transition duration-500" />
                          <div className="absolute top-2 right-2 px-2.5 py-1 bg-zinc-900/90 rounded-lg text-xs font-bold text-amber-400 border border-zinc-700 shadow-lg">
                            {item.price}
                          </div>
                        </div>

                        <div className="p-4 flex-1 flex flex-col justify-between space-y-2">
                          <div>
                            <h4 className="font-bold text-base text-white leading-snug">{item.name}</h4>
                            <p className="text-xs text-zinc-400 line-clamp-2 mt-1">{item.description}</p>
                          </div>

                          <div className="pt-3 border-t border-zinc-800 flex items-center justify-between gap-2">
                            <button
                              onClick={() => handleStartEditMenu(item)}
                              className="flex-1 py-2 rounded-lg bg-zinc-800 hover:bg-amber-500 hover:text-zinc-950 text-zinc-300 font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                              <span>Edit Menu</span>
                            </button>
                            <button
                              onClick={() => {
                                if (confirm(`Yakin ingin menghapus menu "${item.name}"?`)) {
                                  deleteMenuItem(item.id);
                                }
                              }}
                              className="px-3 py-2 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 font-bold text-xs flex items-center justify-center transition cursor-pointer"
                              title="Hapus"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* --- TAB CONTENT 2: QUICK LINKS --- */}
      {activeTab === 'links' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <h3 className="text-xl font-extrabold text-white font-['Outfit']">Manajemen Linktree Bio</h3>
            {!isAddingLink && !editingLinkId && (
              <button
                onClick={handleStartAddLink}
                className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 text-zinc-950 font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg hover:scale-[1.02] transition cursor-pointer"
              >
                <Plus className="w-4 h-4 text-zinc-950" />
                <span>Tambah Link Baru</span>
              </button>
            )}
          </div>

          {(isAddingLink || editingLinkId) && (
            <div className="bg-zinc-900 border-2 border-amber-500 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 animate-in zoom-in-95 duration-200">
              <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
                <h4 className="text-xl font-bold text-white font-['Outfit'] flex items-center gap-2">
                  <LinkIcon className="w-5 h-5 text-amber-500" />
                  <span>{isAddingLink ? 'Tambah Tautan Bio Baru' : `Edit Tautan: ${linkForm.title}`}</span>
                </h4>
                <button
                  onClick={() => { setIsAddingLink(false); setEditingLinkId(null); }}
                  className="px-4 py-2 rounded-lg bg-zinc-800 text-zinc-400 hover:text-white text-xs font-bold cursor-pointer"
                >
                  Batal
                </button>
              </div>

              <form onSubmit={handleSaveLink} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-zinc-300 uppercase">Judul Link / Tombol *</label>
                    <input
                      type="text"
                      required
                      placeholder="Contoh: Order via WhatsApp Bireuen"
                      value={linkForm.title}
                      onChange={e => setLinkForm({...linkForm, title: e.target.value})}
                      className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-zinc-300 uppercase">Keterangan / Subtitle</label>
                    <input
                      type="text"
                      placeholder="Contoh: Respons cepat & pengantaran langsung"
                      value={linkForm.subtitle}
                      onChange={e => setLinkForm({...linkForm, subtitle: e.target.value})}
                      className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-zinc-300 uppercase">Tujuan URL / Link *</label>
                    <input
                      type="text"
                      required
                      placeholder="https://wa.me/628981125445 atau https://instagram.com/..."
                      value={linkForm.url}
                      onChange={e => setLinkForm({...linkForm, url: e.target.value})}
                      className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-amber-500 font-mono"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-zinc-300 uppercase">Badge Label (Opsional)</label>
                    <input
                      type="text"
                      placeholder="Contoh: Diskon 15% / Fast Response"
                      value={linkForm.badge}
                      onChange={e => setLinkForm({...linkForm, badge: e.target.value})}
                      className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-4 pt-4 border-t border-zinc-800">
                  <button
                    type="submit"
                    className="flex-1 py-4 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 font-extrabold text-zinc-950 text-sm shadow-xl hover:opacity-95 flex items-center justify-center gap-2 cursor-pointer transition"
                  >
                    <Check className="w-5 h-5 text-zinc-950" />
                    <span>Simpan Tautan Bio</span>
                  </button>
                </div>
              </form>
            </div>
          )}

          <div className="space-y-3 max-w-3xl">
            {data.quickLinks.map(link => (
              <div key={link.id} className="p-4 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-between gap-4 shadow hover:border-zinc-700 transition">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 font-bold text-white">
                    <span className="truncate">{link.title}</span>
                    {link.badge && <span className="text-[10px] bg-amber-500/20 text-amber-400 px-2 py-0.5 rounded shrink-0">{link.badge}</span>}
                  </div>
                  <p className="text-xs text-zinc-400 mt-0.5 truncate">{link.subtitle || link.url}</p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => handleStartEditLink(link)}
                    className="p-2.5 rounded-lg bg-zinc-800 hover:bg-amber-500 hover:text-zinc-950 text-zinc-300 font-bold transition cursor-pointer"
                    title="Edit"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`Hapus link "${link.title}"?`)) deleteQuickLink(link.id);
                    }}
                    className="p-2.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 transition cursor-pointer"
                    title="Hapus"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* --- TAB CONTENT 3: BRAND SETTINGS --- */}
      {activeTab === 'brand' && (
        <form onSubmit={handleSaveBrand} className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 max-w-3xl animate-in slide-in-from-bottom-4 duration-300">
          <div className="pb-4 border-b border-zinc-800 space-y-1">
            <h3 className="text-xl font-extrabold text-white font-['Outfit']">Pengaturan Identitas & Nomor WhatsApp</h3>
            <p className="text-xs text-zinc-400">Pastikan nomor WhatsApp aktif untuk menerima pesanan otomatis dari kasir digital.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="block text-xs font-bold text-zinc-300 uppercase">Nama Brand *</label>
              <input
                type="text"
                required
                value={brandForm.name}
                onChange={e => setBrandForm({...brandForm, name: e.target.value})}
                className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="space-y-2">
              <label className="block text-xs font-bold text-zinc-300 uppercase">Nomor WhatsApp Reservasi *</label>
              <input
                type="text"
                required
                value={brandForm.whatsappPhone}
                onChange={e => setBrandForm({...brandForm, whatsappPhone: e.target.value})}
                placeholder="+628981125445"
                className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-amber-500 font-mono"
              />
            </div>

            <div className="space-y-2">
              <label className="block text-xs font-bold text-zinc-300 uppercase">Instagram Handle</label>
              <input
                type="text"
                value={brandForm.handle}
                onChange={e => setBrandForm({...brandForm, handle: e.target.value})}
                className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="space-y-2">
              <label className="block text-xs font-bold text-zinc-300 uppercase">Jam Operasional</label>
              <input
                type="text"
                value={brandForm.hours}
                onChange={e => setBrandForm({...brandForm, hours: e.target.value})}
                className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div className="space-y-3 p-5 rounded-2xl bg-zinc-950 border border-zinc-800">
            <label className="block text-xs font-bold text-amber-400 uppercase">Logo / Foto Profil Utama Brand</label>
            <div className="flex flex-col sm:flex-row items-center gap-6">
              {brandForm.logo && (
                <div className="relative">
                  <div className="absolute -inset-1 rounded-full bg-amber-500/20 blur-sm"></div>
                  <img src={brandForm.logo} alt="Logo Preview" className="relative w-24 h-24 rounded-full object-cover border-2 border-amber-500 shadow-xl" />
                </div>
              )}
              <div className="flex-1 w-full space-y-3">
                <input
                  type="file"
                  accept="image/*"
                  id="brand-logo-upload"
                  onChange={e => handleImageUpload(e, base64 => setBrandForm({...brandForm, logo: base64}))}
                  className="hidden"
                />
                <label htmlFor="brand-logo-upload" className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs cursor-pointer border border-zinc-700 shadow transition">
                  <Upload className="w-4 h-4 text-amber-500" />
                  <span>Upload Foto Brand Baru</span>
                </label>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-zinc-500 uppercase font-bold">Atau URL:</span>
                  <input
                    type="url"
                    value={brandForm.logo || ''}
                    onChange={e => setBrandForm({...brandForm, logo: e.target.value})}
                    className="flex-1 bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-1.5 text-[11px] text-zinc-400 focus:outline-none focus:border-amber-500"
                    placeholder="https://..."
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-xs font-bold text-zinc-300 uppercase">Slogan / Tagline Bio</label>
            <input
              type="text"
              value={brandForm.tagline}
              onChange={e => setBrandForm({...brandForm, tagline: e.target.value})}
              className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-xs font-bold text-zinc-300 uppercase">Deskripsi Singkat Tentang Kami</label>
            <textarea
              rows={3}
              value={brandForm.shortDesc}
              onChange={e => setBrandForm({...brandForm, shortDesc: e.target.value})}
              className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="pt-4 border-t border-zinc-800">
            <button
              type="submit"
              className="w-full py-4 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 font-extrabold text-zinc-950 text-sm shadow-xl hover:opacity-95 flex items-center justify-center gap-2 cursor-pointer transition"
            >
              <Check className="w-5 h-5 text-zinc-950" />
              <span>Simpan Identitas & Nomor WA</span>
            </button>
          </div>
        </form>
      )}

      {/* --- TAB CONTENT 4: MERCHANDISE --- */}
      {activeTab === 'merch' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <h3 className="text-xl font-extrabold text-white font-['Outfit']">Manajemen Merchandise & Biji Kopi</h3>
            {!isAddingMerch && !editingMerchId && (
              <button
                onClick={handleStartAddMerch}
                className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 text-zinc-950 font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg hover:scale-[1.02] transition cursor-pointer"
              >
                <Plus className="w-5 h-5 text-zinc-950" />
                <span>Tambah Merchandise</span>
              </button>
            )}
          </div>

          {(isAddingMerch || editingMerchId) && (
            <div className="bg-zinc-900 border-2 border-amber-500 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 animate-in zoom-in-95 duration-200 max-w-2xl">
              <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
                <h4 className="text-xl font-bold text-white font-['Outfit'] flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5 text-amber-500" />
                  <span>{isAddingMerch ? 'Tambah Item Merch Baru' : `Edit Merch: ${merchForm.name}`}</span>
                </h4>
                <button
                  onClick={() => { setIsAddingMerch(false); setEditingMerchId(null); }}
                  className="px-4 py-2 rounded-lg bg-zinc-800 text-zinc-400 hover:text-white text-xs font-bold cursor-pointer"
                >
                  Batal
                </button>
              </div>

              <form onSubmit={handleSaveMerch} className="space-y-6">
                <div className="space-y-2">
                  <label className="block text-xs font-bold text-zinc-300 uppercase">Nama Produk Merch / Beans *</label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Gayo Premium Beans 250g"
                    value={merchForm.name}
                    onChange={e => setMerchForm({...merchForm, name: e.target.value})}
                    className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="space-y-2">
                  <label className="block text-xs font-bold text-zinc-300 uppercase">Harga *</label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Rp 85.000"
                    value={merchForm.price}
                    onChange={e => setMerchForm({...merchForm, price: e.target.value})}
                    className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="space-y-3 p-4 rounded-2xl bg-zinc-950 border border-zinc-800">
                  <label className="block text-xs font-bold text-amber-400 uppercase">Foto Produk (Upload / URL)</label>
                  <div className="flex items-center gap-4">
                    {merchForm.image && <img src={merchForm.image} alt="Preview" className="w-20 h-20 object-cover rounded-xl border border-amber-500" />}
                    <div className="space-y-3 flex-1">
                      <input
                        type="file"
                        accept="image/*"
                        id="merch-photo-upload"
                        onChange={e => handleImageUpload(e, base => setMerchForm({...merchForm, image: base}))}
                        className="hidden"
                      />
                      <label htmlFor="merch-photo-upload" className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs cursor-pointer border border-zinc-700 shadow transition">
                        <Upload className="w-4 h-4 text-amber-500" />
                        <span>Upload Foto Perangkat</span>
                      </label>
                      <input
                        type="url"
                        placeholder="Atau URL Foto..."
                        value={merchForm.image}
                        onChange={e => setMerchForm({...merchForm, image: e.target.value})}
                        className="w-full bg-zinc-900 border border-zinc-700 rounded-xl px-3 py-1.5 text-xs text-zinc-300 focus:outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="block text-xs font-bold text-zinc-300 uppercase">Deskripsi</label>
                  <textarea
                    rows={3}
                    placeholder="Deskripsi bahan kaos atau profil roasting biji kopi..."
                    value={merchForm.desc}
                    onChange={e => setMerchForm({...merchForm, desc: e.target.value})}
                    className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="pt-4 border-t border-zinc-800">
                  <button type="submit" className="w-full py-4 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 font-extrabold text-zinc-950 text-sm shadow-xl hover:opacity-95 flex items-center justify-center gap-2 cursor-pointer transition">
                    <Check className="w-5 h-5 text-zinc-950" />
                    <span>Simpan Merchandise</span>
                  </button>
                </div>
              </form>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {data.merch.map(item => (
              <div key={item.id} className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-lg p-4 flex flex-col justify-between group">
                <img src={item.image} alt={item.name} className="w-full h-40 object-cover rounded-xl mb-3 group-hover:scale-[1.02] transition duration-300" />
                <div className="space-y-1 mb-4">
                  <div className="flex items-center justify-between gap-2">
                    <h4 className="font-bold text-white text-base leading-snug truncate">{item.name}</h4>
                    <span className="font-extrabold text-amber-400 text-sm shrink-0">{item.price}</span>
                  </div>
                  <p className="text-xs text-zinc-400 line-clamp-2">{item.desc}</p>
                </div>

                <div className="pt-3 border-t border-zinc-800 flex items-center justify-between gap-2">
                  <button onClick={() => handleStartEditMerch(item)} className="flex-1 py-2 rounded-lg bg-zinc-800 hover:bg-amber-500 hover:text-zinc-950 text-zinc-300 font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer">
                    <Edit2 className="w-3.5 h-3.5" />
                    <span>Edit Item</span>
                  </button>
                  <button onClick={() => { if (confirm(`Hapus merch "${item.name}"?`)) deleteMerchItem(item.id); }} className="px-3 py-2 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 font-bold text-xs flex items-center justify-center transition cursor-pointer">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* --- TAB CONTENT 5: USER REVIEWS --- */}
      {activeTab === 'reviews' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <h3 className="text-xl font-extrabold text-white font-['Outfit']">Moderasi Ulasan Pembeli</h3>
            <p className="text-xs text-zinc-400">Tinjau pendapat pembeli tentang menu Starblack dan kelola ulasan yang masuk.</p>
          </div>

          <div className="space-y-4">
            {data.userReviews.length === 0 ? (
              <div className="p-16 text-center bg-zinc-900 border border-zinc-800 rounded-3xl">
                <MessageCircle className="w-12 h-12 text-zinc-700 mx-auto mb-4" />
                <p className="text-zinc-500 font-medium italic">Belum ada ulasan dari pembeli saat ini.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {data.userReviews.map((rev) => {
                  const menuItem = data.menuItems.find(i => i.id === rev.itemId);
                  return (
                    <div key={rev.id} className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 flex flex-col sm:flex-row justify-between gap-6 hover:border-amber-500/30 transition">
                      <div className="flex gap-4 flex-1">
                        <div className="w-16 h-16 rounded-xl bg-zinc-950 overflow-hidden shrink-0 border border-zinc-800 shadow">
                          {menuItem ? (
                            <img src={menuItem.image} alt={menuItem.name} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-zinc-700">
                              <Coffee className="w-6 h-6" />
                            </div>
                          )}
                        </div>
                        <div className="space-y-2">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-bold text-white text-lg">{rev.userName}</span>
                            <span className="text-xs text-zinc-500">• {rev.date}</span>
                            <span className="px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-500 text-[10px] font-bold uppercase">
                              Menu: {menuItem?.name || 'Item dihapus'}
                            </span>
                          </div>
                          <div className="flex items-center gap-1">
                            {[...Array(5)].map((_, i) => (
                              <Star key={i} className={`w-3.5 h-3.5 ${i < rev.rating ? 'fill-amber-500 text-amber-500' : 'text-zinc-800'}`} />
                            ))}
                          </div>
                          <p className="text-sm text-zinc-300 leading-relaxed italic">
                            "{rev.comment}"
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 self-end sm:self-center">
                        <button
                           onClick={() => {
                             if (confirm(`Hapus ulasan dari "${rev.userName}"?`)) {
                               deleteUserReview(rev.id);
                             }
                           }}
                           className="px-4 py-2.5 rounded-xl bg-red-500/10 hover:bg-red-500 text-red-400 hover:text-white font-bold text-xs flex items-center gap-2 transition cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                          <span>Hapus Ulasan</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* --- TAB CONTENT 6: SECURITY & PIN SETTINGS --- */}
      {activeTab === 'security' && (
        <div className="space-y-6 max-w-2xl">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-amber-500/10 rounded-xl border border-amber-500/20 text-amber-500">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-extrabold text-white font-['Outfit']">Pengaturan Keamanan Akun</h3>
              <p className="text-xs text-zinc-400">Ganti PIN secara berkala untuk menjaga keamanan data website.</p>
            </div>
          </div>

          <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
            <div className="flex items-center gap-2 px-4 py-3 bg-blue-500/10 border border-blue-500/20 rounded-xl text-blue-400">
              <AlertTriangle className="w-5 h-5 shrink-0" />
              <p className="text-xs leading-relaxed font-medium">
                <strong>Peringatan Keamanan:</strong> Jangan berikan PIN Anda kepada siapapun. Website ini menggunakan sistem enkripsi lokal (browser-based) untuk mencegah serangan virus skrip luar.
              </p>
            </div>

            <form onSubmit={handleUpdatePin} className="space-y-5">
              <div className="space-y-2">
                <label className="block text-xs font-bold text-zinc-300 uppercase">PIN Saat Ini</label>
                <input
                  type="password"
                  required
                  autoComplete="off"
                  value={securityForm.currentPin}
                  onChange={e => setSecurityForm({...securityForm, currentPin: e.target.value})}
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-amber-500 font-mono tracking-widest"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="block text-xs font-bold text-zinc-300 uppercase">PIN Baru</label>
                  <input
                    type="password"
                    required
                    minLength={4}
                    value={securityForm.newPin}
                    onChange={e => setSecurityForm({...securityForm, newPin: e.target.value})}
                    className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-amber-500 font-mono tracking-widest"
                  />
                </div>
                <div className="space-y-2">
                  <label className="block text-xs font-bold text-zinc-300 uppercase">Konfirmasi PIN Baru</label>
                  <input
                    type="password"
                    required
                    value={securityForm.confirmPin}
                    onChange={e => setSecurityForm({...securityForm, confirmPin: e.target.value})}
                    className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-amber-500 font-mono tracking-widest"
                  />
                </div>
              </div>

              {securityMsg.text && (
                <div className={`p-4 rounded-xl text-xs font-bold text-center animate-in zoom-in-95 ${
                  securityMsg.type === 'success' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                }`}>
                  {securityMsg.text}
                </div>
              )}

              <button
                type="submit"
                className="w-full py-4 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 font-extrabold text-zinc-950 text-sm shadow-xl hover:opacity-95 transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Check className="w-5 h-5" />
                <span>Simpan PIN Baru</span>
              </button>
            </form>
          </div>
          
          <div className="p-6 rounded-3xl bg-zinc-950 border border-zinc-800 space-y-4">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              <span>Anti-Virus & Firewall Website</span>
            </h4>
            <ul className="space-y-2">
              {[
                "Input Sanitization: Mencegah injeksi kode berbahaya (Cross-Site Scripting).",
                "Local Storage Encryption: Data disimpan secara aman di browser Anda.",
                "Auto-Logout System: Sesi admin otomatis berakhir saat PIN diganti.",
                "Zero-Server Exposure: Website ini aman dari serangan database server karena berjalan secara statis (Single-File App)."
              ].map((point, idx) => (
                <li key={idx} className="flex items-start gap-2 text-[11px] text-zinc-500 leading-relaxed">
                  <Check className="w-3 h-3 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{point}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

    </div>
  );
};
