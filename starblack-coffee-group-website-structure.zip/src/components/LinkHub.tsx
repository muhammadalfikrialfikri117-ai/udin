import React from 'react';
import { 
  MessageCircle, 
  ShoppingBag, 
  MapPin, 
  Globe, 
  Radio, 
  Package, 
  Users, 
  ArrowRight,
  ExternalLink,
  Sparkles
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ReviewItem } from '../data/coffeeData';

interface LinkHubProps {
  setActiveTab: (tab: string) => void;
}

export const LinkHub: React.FC<LinkHubProps> = ({ setActiveTab }) => {
  const { data } = useApp();
  const quickLinks = data.quickLinks;
  const reviews = data.reviews;

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'MessageCircle': return <MessageCircle className="w-6 h-6" />;
      case 'ShoppingBag': return <ShoppingBag className="w-6 h-6" />;
      case 'MapPin': return <MapPin className="w-6 h-6" />;
      case 'Instagram': return <Globe className="w-6 h-6" />;
      case 'Radio': return <Radio className="w-6 h-6" />;
      case 'Package': return <Package className="w-6 h-6" />;
      case 'Users': return <Users className="w-6 h-6" />;
      default: return <ExternalLink className="w-6 h-6" />;
    }
  };

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, url: string) => {
    if (url.startsWith('#')) {
      e.preventDefault();
      const target = url.replace('#', '');
      if (target === 'menu-section') setActiveTab('menu');
      if (target === 'merch-section') setActiveTab('merch');
      if (target === 'coworking-section') setActiveTab('coworking');
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-6 space-y-12 animate-in fade-in duration-300">
      
      {/* Featured Promo Banner */}
      <div className="relative overflow-hidden rounded-3xl p-6 sm:p-8 bg-gradient-to-r from-amber-500/20 via-orange-600/20 to-amber-500/10 border border-amber-500/30 text-left shadow-2xl">
        <div className="absolute -right-10 -bottom-10 w-48 h-48 bg-amber-500/20 rounded-full blur-2xl pointer-events-none"></div>
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500 text-zinc-950 font-bold text-xs uppercase tracking-wider mb-3">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Secret Menu Drop</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-bold text-white mb-1 font-['Outfit']">
              Try Our Palm Sugar Aren Latte!
            </h3>
            <p className="text-zinc-300 text-sm sm:text-base max-w-md">
              Order today and claim your 15% discount for first-time GoFood & GrabFood delivery.
            </p>
          </div>
          <button
            onClick={() => setActiveTab('menu')}
            className="self-start sm:self-center px-6 py-3 rounded-xl bg-white hover:bg-zinc-100 text-zinc-900 font-bold text-sm shadow-lg flex items-center gap-2 transition shrink-0 cursor-pointer"
          >
            <span>View Menu</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Linktree Buttons List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between px-2 mb-2">
          <h2 className="text-sm font-bold text-zinc-400 uppercase tracking-widest font-['Outfit']">
            Quick Links & Reservations
          </h2>
          <span className="text-xs text-amber-500 font-semibold">{quickLinks.length} Tautan Tersedia</span>
        </div>

        {quickLinks.map((link) => {
          return (
            <a
              key={link.id}
              href={link.url}
              onClick={(e) => handleLinkClick(e, link.url)}
              target={link.url.startsWith('http') ? '_blank' : '_self'}
              rel="noopener noreferrer"
              className={`group relative flex items-center gap-4 p-4 sm:p-5 rounded-2xl bg-zinc-900/90 hover:bg-zinc-800/90 border border-zinc-800 hover:border-amber-500/50 shadow-lg transition-all duration-300 overflow-hidden transform hover:-translate-y-1 cursor-pointer`}
            >
              {/* Highlight accent line on hover */}
              <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-gradient-to-b from-amber-500 to-orange-600 opacity-0 group-hover:opacity-100 transition-opacity"></div>

              {/* Icon Container */}
              <div className={`p-3.5 rounded-xl text-white shrink-0 shadow-inner ${
                link.color ? `bg-gradient-to-br ${link.color}` : 'bg-zinc-800 group-hover:bg-amber-500 group-hover:text-zinc-950 transition-colors'
              }`}>
                {getIcon(link.iconName)}
              </div>

              {/* Text content */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <h3 className="font-bold text-base sm:text-lg text-white group-hover:text-amber-400 transition-colors truncate font-['Outfit']">
                    {link.title}
                  </h3>
                  {link.badge && (
                    <span className="shrink-0 px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wide uppercase bg-amber-500/10 text-amber-400 border border-amber-500/20">
                      {link.badge}
                    </span>
                  )}
                </div>
                <p className="text-xs sm:text-sm text-zinc-400 group-hover:text-zinc-300 line-clamp-1 transition-colors">
                  {link.subtitle}
                </p>
              </div>

              {/* External Arrow */}
              <div className="shrink-0 text-zinc-500 group-hover:text-amber-400 group-hover:translate-x-1 transition-all">
                <ArrowRight className="w-5 h-5" />
              </div>
            </a>
          );
        })}
      </div>

      {/* Testimonial preview box */}
      <div className="pt-6 border-t border-zinc-800">
        <h2 className="text-center font-bold text-zinc-400 text-sm uppercase tracking-wider mb-6 font-['Outfit']">
          Loved by Steemians & Local Coffee Enthusiasts
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {reviews.map((review: ReviewItem) => (
            <div key={review.id} className="p-5 rounded-2xl bg-zinc-900 border border-zinc-800/80 flex flex-col justify-between shadow-md hover:border-zinc-700 transition">
              <div>
                <div className="flex items-center gap-1 text-amber-400 mb-2">
                  {[...Array(review.rating)].map((_, i) => (
                    <Sparkles key={i} className="w-3.5 h-3.5 fill-amber-400" />
                  ))}
                </div>
                <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed italic mb-4">
                  "{review.content}"
                </p>
              </div>

              <div className="flex items-center gap-3 pt-3 border-t border-zinc-800/60">
                <img src={review.avatar} alt={review.author} className="w-9 h-9 rounded-full object-cover border border-amber-500/40" />
                <div>
                  <h4 className="text-xs font-bold text-white">{review.author}</h4>
                  <p className="text-[10px] text-zinc-400">{review.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
