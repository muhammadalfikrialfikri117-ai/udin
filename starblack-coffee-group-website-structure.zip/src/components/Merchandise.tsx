import React from 'react';
import { Package, ShoppingCart, Sparkles, ShieldCheck } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Merchandise: React.FC = () => {
  const { data } = useApp();
  const merchItems = data.merch;
  const brand = data.brandInfo;
  const whatsappNumber = (brand.whatsappPhone || '+628981125445').replace(/\D/g, '');

  const handleBuyWA = (name: string, price: string) => {
    const text = `Halo ${brand.name}, saya berminat untuk membeli Merchandise: %0A%0A*${name}* (${price})%0A%0AMohon informasi stok dan ongkos kirim. Terima kasih!`;
    window.open(`https://wa.me/${whatsappNumber}?text=${text}`, '_blank');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12 animate-in fade-in duration-300">
      
      {/* Section Header */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 font-semibold text-xs uppercase tracking-wider">
          <Package className="w-3.5 h-3.5" />
          <span>Starblack Apparel & Beans</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-['Outfit']">
          Take Starblack Home
        </h2>
        <p className="text-zinc-400 text-sm sm:text-base leading-relaxed">
          Premium single-origin beans roasted weekly in our Bireuen roastery and exclusive streetwear merch for true coffee lovers.
        </p>
      </div>

      {/* Merch Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {merchItems.map((item) => (
          <div key={item.id} className="group flex flex-col bg-zinc-900 border border-zinc-800 hover:border-amber-500/50 rounded-3xl overflow-hidden shadow-2xl transition-all duration-300 hover:-translate-y-1">
            <div className="relative h-64 w-full bg-zinc-950 overflow-hidden">
              <img src={item.image} alt={item.name} className="w-full h-full object-cover group-hover:scale-105 transition duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-transparent to-transparent opacity-80"></div>
              <div className="absolute top-3 right-3 px-3 py-1 rounded-lg bg-amber-500 text-zinc-950 font-extrabold text-xs shadow-md">
                Official Merch
              </div>
            </div>

            <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between space-y-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-widest font-['Outfit']">Fresh Stock</span>
                  <span className="text-lg font-extrabold text-white">{item.price}</span>
                </div>
                <h3 className="text-xl font-bold text-white group-hover:text-amber-400 transition-colors font-['Outfit']">{item.name}</h3>
                <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">{item.desc}</p>
              </div>

              <div className="space-y-3 pt-4 border-t border-zinc-800">
                <div className="flex items-center gap-2 text-xs text-zinc-400">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>100% Original Starblack Guarantee</span>
                </div>
                <button
                  onClick={() => handleBuyWA(item.name, item.price)}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:opacity-95 text-white font-bold text-sm shadow-xl flex items-center justify-center gap-2 transition cursor-pointer"
                >
                  <ShoppingCart className="w-5 h-5" />
                  <span>Order via WhatsApp</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Shopee & Tokopedia promo banner */}
      <div className="p-8 rounded-3xl bg-gradient-to-br from-zinc-900 to-zinc-950 border border-zinc-800 text-center max-w-3xl mx-auto space-y-4">
        <Sparkles className="w-8 h-8 text-amber-400 mx-auto animate-pulse" />
        <h3 className="text-2xl font-bold text-white font-['Outfit']">Looking for E-Commerce Checkout?</h3>
        <p className="text-sm text-zinc-300 max-w-xl mx-auto leading-relaxed">
          You can also find our freshly roasted Arabica beans and merchandise on official Shopee & Tokopedia stores with free nationwide delivery vouchers.
        </p>
        <div className="flex flex-wrap justify-center gap-4 pt-2">
          <a
            href="https://shopee.co.id"
            target="_blank"
            rel="noopener noreferrer"
            className="px-6 py-3 rounded-xl bg-[#ee4d2d] hover:bg-[#ff5b3a] text-white font-bold text-sm shadow-lg transition"
          >
            Starblack on Shopee
          </a>
          <a
            href="https://tokopedia.com"
            target="_blank"
            rel="noopener noreferrer"
            className="px-6 py-3 rounded-xl bg-[#00aa5b] hover:bg-[#00c96b] text-white font-bold text-sm shadow-lg transition"
          >
            Starblack on Tokopedia
          </a>
        </div>
      </div>

    </div>
  );
};
