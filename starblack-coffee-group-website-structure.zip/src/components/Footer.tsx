import React from 'react';
import { Coffee, MapPin, Globe, ExternalLink, Heart } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface FooterProps {
  setActiveTab: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ setActiveTab }) => {
  const { data } = useApp();
  const brand = data.brandInfo;
  const whatsappNumber = (brand.whatsappPhone || '+628981125445').replace(/\D/g, '');

  return (
    <footer className="bg-zinc-950 border-t border-zinc-800/80 pt-16 pb-12 mt-20 text-zinc-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 lg:gap-12">
          
          {/* Col 1: Brand Info */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('links')}>
              <div className="w-10 h-10 bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden flex items-center justify-center shadow-lg">
                {brand.logo ? (
                   <img src={brand.logo} alt="Logo" className="w-full h-full object-cover" />
                ) : (
                   <Coffee className="w-6 h-6 text-amber-500" />
                )}
              </div>
              <span className="text-xl font-extrabold text-white tracking-tight font-['Outfit']">{brand.name}</span>
            </div>
            <p className="text-sm text-zinc-400 max-w-sm leading-relaxed">
              {brand.shortDesc}
            </p>
            <div className="pt-2 flex items-center gap-3">
              <a
                href={brand.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl bg-zinc-900 hover:bg-amber-500 hover:text-zinc-950 border border-zinc-800 flex items-center justify-center text-zinc-300 transition"
              >
                <Globe className="w-5 h-5" />
              </a>
              <a
                href={brand.tiktokUrl || "https://tiktok.com"}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl bg-zinc-900 hover:bg-amber-500 hover:text-zinc-950 border border-zinc-800 flex items-center justify-center text-zinc-300 transition"
              >
                <span className="font-extrabold text-sm font-mono">TT</span>
              </a>
              <a
                href={`https://wa.me/${whatsappNumber}?text=Halo%20${encodeURIComponent(brand.name)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl bg-zinc-900 hover:bg-emerald-500 hover:text-white border border-zinc-800 flex items-center justify-center text-zinc-300 transition"
              >
                <span className="font-extrabold text-xs">WA</span>
              </a>
            </div>
          </div>

          {/* Col 2: Navigation */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider font-['Outfit']">Quick Hub</h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button onClick={() => setActiveTab('links')} className="hover:text-amber-400 transition cursor-pointer">
                  Linktree Quick Links
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('menu')} className="hover:text-amber-400 transition cursor-pointer">
                  Digital Menu & Delivery
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('locations')} className="hover:text-amber-400 transition cursor-pointer">
                  Branch Locations
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('coworking')} className="hover:text-amber-400 transition cursor-pointer">
                  Co-Working & Events
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('admin')} className="text-amber-500 font-semibold hover:underline cursor-pointer">
                  ⚙️ Admin Dashboard
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Visit Us */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider font-['Outfit']">Our Locations</h4>
            <div className="space-y-3 text-xs">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-zinc-200 block">Kandangan Kota Hub</strong>
                  <span className="text-zinc-400">Jl. Merah Johansyah, South Kalimantan</span>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-zinc-200 block">Bireuen Origin HQ</strong>
                  <span className="text-zinc-400">Pusat Kota Bireuen, Aceh</span>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Banner */}
        <div className="pt-8 border-t border-zinc-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <p>© {new Date().getFullYear()} {brand.name}. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <a
              href="https://linktr.ee/starblackcoffeegroup"
              target="_blank"
              rel="noopener noreferrer"
              className="text-amber-500 hover:underline flex items-center gap-1 font-bold"
            >
              <span>Official Linktree Bio</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            <span className="text-zinc-700">•</span>
            <span className="flex items-center gap-1 text-zinc-500">
              Crafted with <Heart className="w-3 h-3 text-red-500 fill-red-500 inline" /> for coffee lovers
            </span>
          </div>
        </div>

      </div>
    </footer>
  );
};
