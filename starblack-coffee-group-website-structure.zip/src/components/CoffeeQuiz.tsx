import React, { useState } from 'react';
import { Sparkles, RotateCcw, MessageCircle } from 'lucide-react';
import { MenuItem } from '../data/coffeeData';
import { useApp } from '../context/AppContext';

export const CoffeeQuiz: React.FC = () => {
  const { data } = useApp();
  const menuItems = data.menuItems;
  const brand = data.brandInfo;
  const whatsappNumber = (brand.whatsappPhone || '+628981125445').replace(/\D/g, '');

  const [step, setStep] = useState<number>(1);
  const [answers, setAnswers] = useState<{ temp: string; flavor: string; mood: string }>({
    temp: '',
    flavor: '',
    mood: ''
  });
  const [recommendation, setRecommendation] = useState<MenuItem | null>(null);

  const handleSelectAnswer = (key: 'temp' | 'flavor' | 'mood', val: string) => {
    const updated = { ...answers, [key]: val };
    setAnswers(updated);
    
    if (step < 3) {
      setStep(step + 1);
    } else {
      calculateResult(updated);
    }
  };

  const calculateResult = (finalAnswers: { temp: string; flavor: string; mood: string }) => {
    const { flavor, mood } = finalAnswers;
    
    let matchedItem = menuItems[0]; // Default

    if (flavor === 'strong' || mood === 'energy') {
      // Find strong drinks
      matchedItem = menuItems.find(m => m.category === 'drink' && (m.name.toLowerCase().includes('saring') || m.name.toLowerCase().includes('espresso'))) || menuItems[0];
    } else if (flavor === 'traditional') {
      // Find traditional drinks
      matchedItem = menuItems.find(m => m.category === 'drink' && m.name.toLowerCase().includes('sanger')) || menuItems[0];
    } else if (flavor === 'sweet' || mood === 'dessert') {
      // Find sweet snacks or sweet drinks
      matchedItem = menuItems.find(m => (m.category === 'snack' && m.name.toLowerCase().includes('cake')) || m.name.toLowerCase().includes('caramel')) || menuItems[0];
    } else if (flavor === 'non-coffee' || mood === 'chill') {
      // Find non-coffee drinks
      matchedItem = menuItems.find(m => m.category === 'drink' && (m.name.toLowerCase().includes('matcha') || m.name.toLowerCase().includes('refresher'))) || menuItems[0];
    } else if (mood === 'work') {
      // Find manual brew or signature
      matchedItem = menuItems.find(m => m.category === 'drink' && m.name.toLowerCase().includes('v60')) || menuItems[0];
    }

    setRecommendation(matchedItem || menuItems[0]);
    setStep(4);
  };

  const resetQuiz = () => {
    setAnswers({ temp: '', flavor: '', mood: '' });
    setRecommendation(null);
    setStep(1);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 animate-in fade-in duration-300">
      
      {/* Intro */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 font-semibold text-xs uppercase tracking-wider">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Interactive Barista Quiz</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-['Outfit']">
          Find Your Perfect Brew
        </h2>
        <p className="text-zinc-400 text-sm sm:text-base leading-relaxed">
          Not sure what to order? Answer 3 quick questions and let our digital barista recommend your perfect match.
        </p>
      </div>

      {/* Quiz Card Box */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden">
        
        {/* Progress Bar */}
        {step <= 3 && (
          <div className="mb-8 space-y-2">
            <div className="flex items-center justify-between text-xs text-zinc-400 font-bold">
              <span>QUESTION {step} OF 3</span>
              <span>{Math.round((step / 3) * 100)}%</span>
            </div>
            <div className="w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-amber-500 to-orange-600 transition-all duration-300"
                style={{ width: `${(step / 3) * 100}%` }}
              ></div>
            </div>
          </div>
        )}

        {/* Step 1: Temperature */}
        {step === 1 && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <h3 className="text-xl sm:text-2xl font-bold text-white text-center font-['Outfit']">
              How do you like your drink served?
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-lg mx-auto">
              <button
                onClick={() => handleSelectAnswer('temp', 'iced')}
                className="p-6 rounded-2xl bg-zinc-800/80 hover:bg-amber-500/10 border border-zinc-700 hover:border-amber-500/50 text-white font-bold text-lg flex flex-col items-center gap-3 transition cursor-pointer"
              >
                <span className="text-3xl">🧊</span>
                <span>Ice Cold & Refreshing</span>
              </button>
              <button
                onClick={() => handleSelectAnswer('temp', 'hot')}
                className="p-6 rounded-2xl bg-zinc-800/80 hover:bg-amber-500/10 border border-zinc-700 hover:border-amber-500/50 text-white font-bold text-lg flex flex-col items-center gap-3 transition cursor-pointer"
              >
                <span className="text-3xl">☕</span>
                <span>Steaming Hot & Soothing</span>
              </button>
            </div>
          </div>
        )}

        {/* Step 2: Flavor Profile */}
        {step === 2 && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <h3 className="text-xl sm:text-2xl font-bold text-white text-center font-['Outfit']">
              What flavor notes are you craving?
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-xl mx-auto">
              <button
                onClick={() => handleSelectAnswer('flavor', 'sweet')}
                className="p-5 rounded-2xl bg-zinc-800/80 hover:bg-amber-500/10 border border-zinc-700 hover:border-amber-500 text-left transition cursor-pointer"
              >
                <div className="text-2xl mb-1">🍯</div>
                <h4 className="font-bold text-white text-base">Sweet & Creamy</h4>
                <p className="text-xs text-zinc-400">Notes of aren palm sugar, caramel, or velvety vanilla milk.</p>
              </button>

              <button
                onClick={() => handleSelectAnswer('flavor', 'strong')}
                className="p-5 rounded-2xl bg-zinc-800/80 hover:bg-amber-500/10 border border-zinc-700 hover:border-amber-500 text-left transition cursor-pointer"
              >
                <div className="text-2xl mb-1">⚡</div>
                <h4 className="font-bold text-white text-base">Strong & Bold</h4>
                <p className="text-xs text-zinc-400">Pure robust espresso, heavy body, & intense caffeine kick.</p>
              </button>

              <button
                onClick={() => handleSelectAnswer('flavor', 'traditional')}
                className="p-5 rounded-2xl bg-zinc-800/80 hover:bg-amber-500/10 border border-zinc-700 hover:border-amber-500 text-left transition cursor-pointer"
              >
                <div className="text-2xl mb-1">🌿</div>
                <h4 className="font-bold text-white text-base">Traditional Heritage</h4>
                <p className="text-xs text-zinc-400">Legendary Kopi Saring or Sanger with authentic local flair.</p>
              </button>

              <button
                onClick={() => handleSelectAnswer('flavor', 'non-coffee')}
                className="p-5 rounded-2xl bg-zinc-800/80 hover:bg-amber-500/10 border border-zinc-700 hover:border-amber-500 text-left transition cursor-pointer"
              >
                <div className="text-2xl mb-1">🍑</div>
                <h4 className="font-bold text-white text-base">Fruity & Tea Based</h4>
                <p className="text-xs text-zinc-400">Matcha green tea, peach soda fizz, & caffeine alternatives.</p>
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Mood */}
        {step === 3 && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <h3 className="text-xl sm:text-2xl font-bold text-white text-center font-['Outfit']">
              What's the vibe for today's order?
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-xl mx-auto">
              <button
                onClick={() => handleSelectAnswer('mood', 'energy')}
                className="p-5 rounded-2xl bg-zinc-800/80 hover:bg-amber-500/10 border border-zinc-700 hover:border-amber-500 text-left transition cursor-pointer"
              >
                <h4 className="font-bold text-white text-base flex items-center gap-2">
                  <span>🚀 Need an Energy Booster</span>
                </h4>
                <p className="text-xs text-zinc-400 mt-1">Ready to tackle deadlines, meetings, or long drives.</p>
              </button>

              <button
                onClick={() => handleSelectAnswer('mood', 'chill')}
                className="p-5 rounded-2xl bg-zinc-800/80 hover:bg-amber-500/10 border border-zinc-700 hover:border-amber-500 text-left transition cursor-pointer"
              >
                <h4 className="font-bold text-white text-base flex items-center gap-2">
                  <span>🛋️ Casual Hangout & Chill</span>
                </h4>
                <p className="text-xs text-zinc-400 mt-1">Relaxing with friends or listening to acoustic live music.</p>
              </button>

              <button
                onClick={() => handleSelectAnswer('mood', 'dessert')}
                className="p-5 rounded-2xl bg-zinc-800/80 hover:bg-amber-500/10 border border-zinc-700 hover:border-amber-500 text-left transition cursor-pointer"
              >
                <h4 className="font-bold text-white text-base flex items-center gap-2">
                  <span>🍰 Sweet Indulgent Treat</span>
                </h4>
                <p className="text-xs text-zinc-400 mt-1">Pairing with Biscoff cheesecake or almond butter croissants.</p>
              </button>

              <button
                onClick={() => handleSelectAnswer('mood', 'work')}
                className="p-5 rounded-2xl bg-zinc-800/80 hover:bg-amber-500/10 border border-zinc-700 hover:border-amber-500 text-left transition cursor-pointer"
              >
                <h4 className="font-bold text-white text-base flex items-center gap-2">
                  <span>💻 Deep Focus & Co-Working</span>
                </h4>
                <p className="text-xs text-zinc-400 mt-1">Writing code, articles, or studying for exams.</p>
              </button>
            </div>
          </div>
        )}

        {/* Step 4: Result Recommendation */}
        {step === 4 && recommendation && (
          <div className="space-y-8 animate-in zoom-in-95 duration-300">
            <div className="text-center space-y-2">
              <span className="text-xs font-bold text-amber-500 uppercase tracking-widest bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20">
                Your Perfect Barista Match
              </span>
              <h3 className="text-3xl font-extrabold text-white font-['Outfit']">{recommendation.name}</h3>
            </div>

            <div className="max-w-md mx-auto rounded-3xl overflow-hidden bg-zinc-950 border border-zinc-800 shadow-2xl">
              <div className="h-64 relative">
                <img src={recommendation.image} alt={recommendation.name} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-transparent to-transparent opacity-80"></div>
                <div className="absolute bottom-4 right-4 px-3 py-1 rounded-lg bg-amber-500 text-zinc-950 font-extrabold text-base shadow">
                  {recommendation.price}
                </div>
              </div>

              <div className="p-6 space-y-4">
                <p className="text-sm text-zinc-300 leading-relaxed">
                  {recommendation.description}
                </p>

                <div className="flex items-center justify-between text-xs text-zinc-400">
                  <span>★ {recommendation.rating || 4.9} ({recommendation.reviewsCount || 100} reviews)</span>
                  <span>Category: {recommendation.category.toUpperCase()}</span>
                </div>

                <div className="pt-4 border-t border-zinc-800/80 flex flex-col sm:flex-row gap-3">
                  <button
                    onClick={resetQuiz}
                    className="sm:w-1/3 py-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold text-sm flex items-center justify-center gap-1.5 transition cursor-pointer"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>Retake Quiz</span>
                  </button>

                  <button
                    onClick={() => {
                      const text = `Halo ${brand.name}, dari hasil Coffee Quiz di website, saya mau pesan: *${recommendation.name}* (${recommendation.price}). Mohon info ketersediaan.`;
                      window.open(`https://wa.me/${whatsappNumber}?text=${text}`, '_blank');
                    }}
                    className="sm:w-2/3 py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:opacity-90 text-white font-bold text-sm shadow-lg flex items-center justify-center gap-2 transition cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Order This Match via WA</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>

    </div>
  );
};
