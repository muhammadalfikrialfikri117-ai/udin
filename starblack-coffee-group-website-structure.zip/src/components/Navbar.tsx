import React from 'react';
import { Coffee, Share2, PhoneCall, Menu as MenuIcon, X, Settings } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenShare: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, onOpenShare }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const { data } = useApp();
  const brand = data.brandInfo;

  const navLinks = [
    { id: 'links', label: 'Link Hub ⚡' },
    { id: 'menu', label: 'Coffee & Menu ☕' },
    { id: 'locations', label: 'Locations 📍' },
    { id: 'coworking', label: 'Co-Working & Events 👥' },
    { id: 'merch', label: 'Merchandise 🛍️' },
    { id: 'quiz', label: 'Coffee Finder 🔍' },
    { id: 'admin', label: '⚙️ Admin Panel' },
  ];

  const whatsappNumber = (brand.whatsappPhone || '+628981125445').replace(/\D/g, '');

  return (
    <header className="sticky top-0 z-50 bg-[#0b0b0d]/90 backdrop-blur-md border-b border-zinc-800/80 transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo & Brand */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('links')}>
            <div className="relative">
              <div className="absolute -inset-1 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 opacity-70 blur-sm animate-pulse-glow"></div>
              <div className="relative flex items-center justify-center w-12 h-12 bg-zinc-900 rounded-xl border border-zinc-700 text-amber-500 shadow-xl overflow-hidden">
                {brand.logo ? (
                  <img src={brand.logo} alt="Logo" className="w-full h-full object-cover" />
                ) : (
                  <Coffee className="w-6 h-6" />
                )}
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-xl tracking-tight text-white font-['Outfit'] truncate max-w-[150px] sm:max-w-none">
                  {brand.name}
                </span>
              </div>
              <p className="text-xs text-zinc-400 truncate max-w-[180px]">Official Web Portal</p>
            </div>
          </div>

          {/* Desktop Navigation Tabs */}
          <nav className="hidden lg:flex items-center space-x-1 bg-zinc-900/80 p-1.5 rounded-2xl border border-zinc-800">
            {navLinks.map((link) => {
              const isActive = activeTab === link.id;
              const isAdminTab = link.id === 'admin';
              return (
                <button
                  key={link.id}
                  onClick={() => setActiveTab(link.id)}
                  className={`px-3 py-2 rounded-xl text-sm font-medium transition-all duration-200 cursor-pointer ${
                    isActive
                      ? isAdminTab
                        ? 'bg-gradient-to-r from-red-600 to-amber-600 text-white font-bold shadow-md'
                        : 'bg-gradient-to-r from-amber-500 to-orange-600 text-white font-semibold shadow-md shadow-orange-600/20'
                      : isAdminTab
                        ? 'text-amber-400 hover:text-white bg-amber-500/10 border border-amber-500/20 px-3'
                        : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
                  }`}
                >
                  {link.label}
                </button>
              );
            })}
          </nav>

          {/* Right Action Buttons */}
          <div className="flex items-center gap-2.5 sm:gap-3">
            <a
              href={`https://wa.me/${whatsappNumber}?text=Halo%20${encodeURIComponent(brand.name)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:flex items-center gap-2 px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 text-sm font-semibold transition"
            >
              <PhoneCall className="w-4 h-4 text-emerald-400" />
              <span>RSVP / Order</span>
            </a>

            <button
              onClick={onOpenShare}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 text-sm font-semibold transition cursor-pointer"
              title="Share Linktree / Website"
            >
              <Share2 className="w-4 h-4" />
              <span className="hidden md:inline">Share Portal</span>
            </button>

            {/* Mobile menu toggle button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <MenuIcon className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Menu Dropdown (Diperbaiki: menggunakan maxHeight calc dan overflow-y-auto agar bisa discroll/geser ke atas dan bawah) */}
      {mobileMenuOpen && (
        <div className="lg:hidden absolute top-full left-0 right-0 bg-zinc-950/95 border-b border-zinc-800 p-6 backdrop-blur-xl animate-in fade-in slide-in-from-top-4 duration-200 max-h-[calc(100vh-80px)] overflow-y-auto">
          <div className="flex flex-col space-y-2 pb-8">
            {navLinks.map((link) => {
              const isActive = activeTab === link.id;
              const isAdminTab = link.id === 'admin';
              return (
                <button
                  key={link.id}
                  onClick={() => {
                    setActiveTab(link.id);
                    setMobileMenuOpen(false);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className={`w-full text-left px-4 py-4 rounded-xl text-base font-semibold flex items-center justify-between transition cursor-pointer ${
                    isActive
                      ? isAdminTab 
                        ? 'bg-gradient-to-r from-red-600 to-amber-600 text-white shadow-lg font-bold' 
                        : 'bg-gradient-to-r from-amber-500 to-orange-600 text-white shadow-lg shadow-orange-600/20 font-bold'
                      : isAdminTab
                        ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30 font-bold'
                        : 'text-zinc-300 hover:bg-zinc-900 hover:text-white'
                  }`}
                >
                  <span className="flex items-center gap-2.5">
                    {isAdminTab && <Settings className="w-4 h-4 text-amber-400" />}
                    <span>{link.label}</span>
                  </span>
                  {isActive && <span className="w-2 h-2 rounded-full bg-white animate-pulse"></span>}
                </button>
              );
            })}
            
            <div className="pt-6 mt-4 border-t border-zinc-800 flex flex-col gap-3">
              <a
                href={`https://wa.me/${whatsappNumber}?text=Halo%20${encodeURIComponent(brand.name)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-4 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-center flex items-center justify-center gap-2 shadow-lg shadow-emerald-900/30"
              >
                <PhoneCall className="w-5 h-5" />
                <span>WhatsApp Order & RSVP</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
