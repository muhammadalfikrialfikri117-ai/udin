import React from 'react';
import { MapPin, Clock, PhoneCall, ExternalLink, Navigation, Wifi, ShieldCheck, Coffee } from 'lucide-react';
import { LocationItem } from '../data/coffeeData';
import { useApp } from '../context/AppContext';

export const Locations: React.FC = () => {
  const { data } = useApp();
  const locations = data.locations;
  const brand = data.brandInfo;
  const whatsappNumber = (brand.whatsappPhone || '+628981125445').replace(/\D/g, '');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12 animate-in fade-in duration-300">
      
      {/* Section Header */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 font-semibold text-xs uppercase tracking-wider">
          <MapPin className="w-3.5 h-3.5" />
          <span>Our Branches</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-['Outfit']">
          Visit Starblack Hubs
        </h2>
        <p className="text-zinc-400 text-sm sm:text-base leading-relaxed">
          Experience our signature hospitality, aroma, and high-speed co-working environments in Kandangan Kota and Bireuen.
        </p>
      </div>

      {/* Locations List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-10">
        {locations.map((loc: LocationItem) => (
          <div
            key={loc.id}
            className="group relative flex flex-col bg-zinc-900 border border-zinc-800 hover:border-amber-500/50 rounded-3xl overflow-hidden shadow-2xl transition-all duration-300"
          >
            {/* Header Image */}
            <div className="relative h-64 w-full overflow-hidden bg-zinc-950">
              <img
                src={loc.image}
                alt={loc.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-zinc-900/40 to-transparent"></div>
              
              {loc.isHQ && (
                <div className="absolute top-4 left-4 px-3 py-1 bg-amber-500 text-zinc-950 font-extrabold text-xs rounded-full uppercase tracking-wider shadow-lg flex items-center gap-1">
                  <Coffee className="w-3.5 h-3.5" />
                  <span>Main Hub & Roastery</span>
                </div>
              )}

              <div className="absolute bottom-4 left-4 right-4">
                <span className="text-xs font-bold tracking-widest text-amber-400 uppercase font-['Outfit']">{loc.city}</span>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-white font-['Outfit']">{loc.name}</h3>
              </div>
            </div>

            {/* Content Details */}
            <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between space-y-6">
              
              {/* Info rows */}
              <div className="space-y-4 text-sm text-zinc-300">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                  <span className="leading-relaxed">{loc.address}</span>
                </div>

                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-amber-500 shrink-0" />
                  <span className="font-semibold text-zinc-200">{loc.hours}</span>
                </div>

                <div className="flex items-center gap-3">
                  <PhoneCall className="w-5 h-5 text-amber-500 shrink-0" />
                  <span className="text-zinc-200">{loc.phone}</span>
                </div>
              </div>

              {/* Amenities / Facilities */}
              <div className="space-y-2.5 pt-4 border-t border-zinc-800">
                <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider block font-['Outfit']">
                  Space Amenities & Perks
                </span>
                <div className="flex flex-wrap gap-2">
                  {loc.facilities.map((fac, idx) => (
                    <span
                      key={idx}
                      className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-zinc-800/80 text-zinc-300 text-xs border border-zinc-700/50"
                    >
                      {fac.includes('Wi-Fi') ? <Wifi className="w-3.5 h-3.5 text-emerald-400" /> : <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />}
                      <span>{fac}</span>
                    </span>
                  ))}
                </div>
              </div>

              {/* Direct actions */}
              <div className="pt-4 border-t border-zinc-800 flex flex-col sm:flex-row gap-3">
                <a
                  href={loc.mapUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:opacity-95 text-white font-bold text-sm text-center flex items-center justify-center gap-2 shadow-lg shadow-orange-950 transition cursor-pointer"
                >
                  <Navigation className="w-4 h-4" />
                  <span>Open in Google Maps</span>
                </a>

                <a
                  href={`https://wa.me/${whatsappNumber}?text=Halo%20Starblack%20${loc.city},%20ingin%20reservasi%20tempat.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="sm:w-auto px-5 py-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold text-sm text-center flex items-center justify-center gap-2 border border-zinc-700 transition cursor-pointer"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>RSVP Table</span>
                </a>
              </div>

            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
