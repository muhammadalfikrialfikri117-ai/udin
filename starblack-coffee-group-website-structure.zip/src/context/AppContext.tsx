import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  BRAND_INFO as DEFAULT_BRAND_INFO, 
  QUICK_LINKS as DEFAULT_QUICK_LINKS, 
  MENU_ITEMS as DEFAULT_MENU_ITEMS, 
  LOCATIONS as DEFAULT_LOCATIONS, 
  COMMUNITY_EVENTS as DEFAULT_EVENTS, 
  REVIEWS as DEFAULT_REVIEWS, 
  MERCH_ITEMS as DEFAULT_MERCH,
  MenuItem,
  LinkItem,
  LocationItem,
  EventItem,
  ReviewItem
} from '../data/coffeeData';

interface MerchItem {
  id: string;
  name: string;
  price: string;
  desc: string;
  image: string;
}

interface AppData {
  brandInfo: typeof DEFAULT_BRAND_INFO;
  quickLinks: LinkItem[];
  menuItems: MenuItem[];
  locations: LocationItem[];
  events: EventItem[];
  reviews: ReviewItem[];
  merch: MerchItem[];
  userReviews: UserReview[];
  adminPin: string;
}

export interface UserReview {
  id: string;
  itemId: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
}

interface AppContextType {
  data: AppData;
  isAdmin: boolean;
  setIsAdmin: (val: boolean) => void;
  updateBrandInfo: (newInfo: Partial<typeof DEFAULT_BRAND_INFO>) => void;
  addMenuItem: (item: Omit<MenuItem, 'id'>) => void;
  updateMenuItem: (id: string, updated: Partial<MenuItem>) => void;
  deleteMenuItem: (id: string) => void;
  addQuickLink: (link: Omit<LinkItem, 'id'>) => void;
  updateQuickLink: (id: string, updated: Partial<LinkItem>) => void;
  deleteQuickLink: (id: string) => void;
  addMerchItem: (item: Omit<MerchItem, 'id'>) => void;
  updateMerchItem: (id: string, updated: Partial<MerchItem>) => void;
  deleteMerchItem: (id: string) => void;
  addUserReview: (review: Omit<UserReview, 'id' | 'date'>) => void;
  deleteUserReview: (id: string) => void;
  changeAdminPin: (newPin: string) => void;
  resetToDefaults: () => void;
}

const STORAGE_KEY = 'starblack_app_data_v1';

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  
  const [data, setData] = useState<AppData>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Ensure new fields like 'logo' are merged if they don't exist in saved data
        return {
          ...parsed,
          brandInfo: { ...DEFAULT_BRAND_INFO, ...parsed.brandInfo },
          adminPin: parsed.adminPin || '1234',
          userReviews: parsed.userReviews || []
        };
      } catch (e) {
        console.error("Failed to load saved data", e);
      }
    }
    return {
      brandInfo: DEFAULT_BRAND_INFO,
      quickLinks: DEFAULT_QUICK_LINKS,
      menuItems: DEFAULT_MENU_ITEMS,
      locations: DEFAULT_LOCATIONS,
      events: DEFAULT_EVENTS,
      reviews: DEFAULT_REVIEWS,
      merch: DEFAULT_MERCH,
      userReviews: [],
      adminPin: '1234'
    };
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }, [data]);

  const changeAdminPin = (newPin: string) => {
    setData(prev => ({
      ...prev,
      adminPin: newPin
    }));
  };

  const updateBrandInfo = (newInfo: Partial<typeof DEFAULT_BRAND_INFO>) => {
    setData(prev => ({
      ...prev,
      brandInfo: { ...prev.brandInfo, ...newInfo }
    }));
  };

  const addMenuItem = (item: Omit<MenuItem, 'id'>) => {
    const id = `m_${Date.now()}`;
    setData(prev => ({
      ...prev,
      menuItems: [{ ...item, id }, ...prev.menuItems]
    }));
  };

  const updateMenuItem = (id: string, updated: Partial<MenuItem>) => {
    setData(prev => ({
      ...prev,
      menuItems: prev.menuItems.map(item => item.id === id ? { ...item, ...updated } : item)
    }));
  };

  const deleteMenuItem = (id: string) => {
    setData(prev => ({
      ...prev,
      menuItems: prev.menuItems.filter(item => item.id !== id)
    }));
  };

  const addQuickLink = (link: Omit<LinkItem, 'id'>) => {
    const id = `link_${Date.now()}`;
    setData(prev => ({
      ...prev,
      quickLinks: [...prev.quickLinks, { ...link, id }]
    }));
  };

  const updateQuickLink = (id: string, updated: Partial<LinkItem>) => {
    setData(prev => ({
      ...prev,
      quickLinks: prev.quickLinks.map(link => link.id === id ? { ...link, ...updated } : link)
    }));
  };

  const deleteQuickLink = (id: string) => {
    setData(prev => ({
      ...prev,
      quickLinks: prev.quickLinks.filter(link => link.id !== id)
    }));
  };

  const addMerchItem = (item: Omit<MerchItem, 'id'>) => {
    const id = `merch_${Date.now()}`;
    setData(prev => ({
      ...prev,
      merch: [{ ...item, id }, ...prev.merch]
    }));
  };

  const updateMerchItem = (id: string, updated: Partial<MerchItem>) => {
    setData(prev => ({
      ...prev,
      merch: prev.merch.map(item => item.id === id ? { ...item, ...updated } : item)
    }));
  };

  const deleteMerchItem = (id: string) => {
    setData(prev => ({
      ...prev,
      merch: prev.merch.filter(item => item.id !== id)
    }));
  };

  const addUserReview = (review: Omit<UserReview, 'id' | 'date'>) => {
    const id = `rev_${Date.now()}`;
    const date = new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
    setData(prev => ({
      ...prev,
      userReviews: [{ ...review, id, date }, ...prev.userReviews]
    }));
  };

  const deleteUserReview = (id: string) => {
    setData(prev => ({
      ...prev,
      userReviews: prev.userReviews.filter(rev => rev.id !== id)
    }));
  };

  const resetToDefaults = () => {
    if (confirm("Apakah Anda yakin ingin mereset seluruh data kembali ke bawaan pabrik (default)?")) {
      const defaultData: AppData = {
        brandInfo: DEFAULT_BRAND_INFO,
        quickLinks: DEFAULT_QUICK_LINKS,
        menuItems: DEFAULT_MENU_ITEMS,
        locations: DEFAULT_LOCATIONS,
        events: DEFAULT_EVENTS,
        reviews: DEFAULT_REVIEWS,
        merch: DEFAULT_MERCH,
        userReviews: [],
        adminPin: '1234'
      };
      setData(defaultData);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(defaultData));
      alert("Data berhasil direset ke pengaturan awal.");
    }
  };

  return (
    <AppContext.Provider value={{
      data,
      isAdmin,
      setIsAdmin,
      updateBrandInfo,
      addMenuItem,
      updateMenuItem,
      deleteMenuItem,
      addQuickLink,
      updateQuickLink,
      deleteQuickLink,
      addMerchItem,
      updateMerchItem,
      deleteMerchItem,
      addUserReview,
      deleteUserReview,
      changeAdminPin,
      resetToDefaults
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error("useApp must be used within an AppProvider");
  return context;
};
