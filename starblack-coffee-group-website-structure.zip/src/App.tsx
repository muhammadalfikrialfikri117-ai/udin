import { useState } from 'react';
import { AppProvider } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { LinkHub } from './components/LinkHub';
import { DigitalMenu } from './components/DigitalMenu';
import { Locations } from './components/Locations';
import { CoWorking } from './components/CoWorking';
import { Merchandise } from './components/Merchandise';
import { CoffeeQuiz } from './components/CoffeeQuiz';
import { AdminPanel } from './components/AdminPanel';
import { ShareModal } from './components/ShareModal';
import { Footer } from './components/Footer';

function AppContent() {
  const [activeTab, setActiveTab] = useState<string>('links');
  const [isShareModalOpen, setIsShareModalOpen] = useState<boolean>(false);

  return (
    <div className="min-h-screen bg-[#0b0b0d] text-zinc-100 flex flex-col selection:bg-amber-500 selection:text-zinc-950 font-['Plus_Jakarta_Sans']">
      
      {/* Top sticky Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenShare={() => setIsShareModalOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1">
        
        {/* Hero Section (only shown when not in admin mode for cleaner focus) */}
        {activeTab !== 'admin' && <Hero setActiveTab={setActiveTab} />}

        {/* Dynamic Tab Content Switcher */}
        <div className="transition-all duration-300 min-h-[500px]">
          {activeTab === 'links' && <LinkHub setActiveTab={setActiveTab} />}
          {activeTab === 'menu' && <DigitalMenu />}
          {activeTab === 'locations' && <Locations />}
          {activeTab === 'coworking' && <CoWorking />}
          {activeTab === 'merch' && <Merchandise />}
          {activeTab === 'quiz' && <CoffeeQuiz />}
          {activeTab === 'admin' && <AdminPanel />}
        </div>

      </main>

      {/* Share / QR Code Popup Modal */}
      <ShareModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
      />

      {/* Footer */}
      <Footer setActiveTab={setActiveTab} />

    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
